# StreamFlow - Streaming Platform

StreamFlow is a comprehensive streaming platform built with Streamlit that supports VLC and RTMP protocols, with WordPress integration capabilities.

## Features

- Stream media content using VLC and RTMP protocols
- Admin dashboard for content and user management
- User management system with different permission levels
- Media library for organizing content
- Customizable streaming settings
- WordPress plugin integration for embedding streams
- Support for iframe and shortcode embedding
- Dependency installation helpers

## Default Admin Credentials

The platform comes with a default admin account:
- **Username:** admin
- **Password:** admin

These credentials can be used to access the admin dashboard and manage the platform. For security purposes, it's recommended to change the default password after first login.

## Admin Dashboard Access

Upon successful login with admin credentials, you'll be automatically redirected to the Admin Dashboard. The Admin Dashboard is hidden from regular users and can also be accessed by directly visiting the configured admin URL path (customizable in settings).

## Installation

### Prerequisites

- Python 3.7 or higher
- Streamlit
- FFmpeg (for video processing)
- VLC (for VLC streaming support)
- Additional Python packages: python-vlc, ffmpeg-python, pyyaml, psutil

### Automatic Installation

For convenience, we've included an installation script that will set up all necessary dependencies:

1. Make the installation script executable:

```bash
chmod +x install_dependencies.sh
```

2. Run the installation script:

```bash
./install_dependencies.sh
```

This script will:
- Verify Python 3 is installed
- Update package lists (requires sudo)
- Install FFmpeg and VLC (requires sudo)
- Install required Python packages via pip
- Create necessary directories
- Configure Streamlit settings

### Manual Installation

If you prefer to install dependencies manually:

1. Install system dependencies:

```bash
# For Debian/Ubuntu-based systems
sudo apt update
sudo apt install -y ffmpeg vlc
```

2. Install Python packages:

```bash
pip install streamlit python-vlc ffmpeg-python pyyaml psutil
```

3. Create Streamlit configuration:

```bash
mkdir -p .streamlit
cat > .streamlit/config.toml << EOL
[server]
headless = true
address = "0.0.0.0"
port = 5000

[theme]
primaryColor = "#f63366"
backgroundColor = "#0e1117"
secondaryBackgroundColor = "#1a1c24"
textColor = "#fafafa"

[browser]
gatherUsageStats = false
EOL
```

## Running the Application

Start the StreamFlow application with:

```bash
streamlit run app.py --server.port 5000
```

The application will be available at `http://localhost:5000`

## Directory Structure

```
├── .streamlit/            # Streamlit configuration
├── media/                 # Media storage directories
│   ├── hls/               # HLS stream segments
│   └── thumbnails/        # Media thumbnails
├── pages/                 # Application pages
│   ├── 01_Media_Player.py # Media player interface
│   ├── 02_My_Library.py   # User's media library
│   ├── 03_Stream_Setup.py # Stream configuration
│   ├── 04_Admin_Dashboard.py # Admin controls
│   ├── 05_Settings.py     # User settings
│   └── 06_WordPress_Integration.py # WP integration
├── templates/             # Templates for integrations
│   └── wordpress/         # WordPress templates
├── utils/                 # Utility modules
│   ├── auth.py            # Authentication system
│   ├── install.py         # Installation utilities
│   ├── media.py           # Media handling
│   ├── session.py         # Session state management
│   ├── stream.py          # Streaming functionality
│   └── wordpress.py       # WordPress integration
├── app.py                 # Main application entry
├── config.yaml            # Application configuration
└── install_dependencies.sh # Installation script
```

## Configuration

The application can be configured by editing the `config.yaml` file. Key configuration options include:

- `site_name`: The name of your streaming platform
- `allow_registration`: Whether to allow new user registrations
- `require_approval`: Whether new users require admin approval
- `rtmp_server`: RTMP server URL for streaming
- `default_player`: Default media player (vlc or html5)
- `auth.admin_dashboard_path`: Custom URL path for admin dashboard

## WordPress Integration

StreamFlow includes WordPress integration capabilities:

1. Configure your WordPress connection in the WordPress Integration page
2. Use the provided plugin code to add streaming capabilities to your WordPress site
3. Embed streams using shortcodes: `[streamflow_player stream="YOUR_STREAM_KEY"]`

## Security Considerations

- Change the default admin password immediately after installation
- Consider setting a custom admin dashboard URL path for enhanced security
- When using in production, set up proper authentication and consider using HTTPS
