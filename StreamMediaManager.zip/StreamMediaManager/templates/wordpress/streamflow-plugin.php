<?php
/**
 * Plugin Name: StreamFlow Integration
 * Plugin URI: https://github.com/yourusername/streamflow
 * Description: Integrates your WordPress site with the StreamFlow streaming platform
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL2
 */

// Make sure we don't expose any info if called directly
if (!function_exists('add_action')) {
    echo 'Hi there! I\'m just a plugin, not much I can do when called directly.';
    exit;
}

// Define plugin constants
define('STREAMFLOW_VERSION', '1.0.0');
define('STREAMFLOW_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('STREAMFLOW_PLUGIN_URL', plugin_dir_url(__FILE__));

// StreamFlow API settings
define('STREAMFLOW_API_URL', get_option('streamflow_api_url', ''));
define('STREAMFLOW_API_KEY', get_option('streamflow_api_key', ''));

// Register activation hook
register_activation_hook(__FILE__, 'streamflow_activate');
function streamflow_activate() {
    // Set default options
    add_option('streamflow_api_url', '');
    add_option('streamflow_api_key', '');
    add_option('streamflow_embed_width', '100%');
    add_option('streamflow_embed_height', '480');
    
    // Create custom post type
    streamflow_create_post_types();
    
    // Flush rewrite rules
    flush_rewrite_rules();
}

// Register deactivation hook
register_deactivation_hook(__FILE__, 'streamflow_deactivate');
function streamflow_deactivate() {
    // Flush rewrite rules
    flush_rewrite_rules();
}

// Create custom post type for streams
function streamflow_create_post_types() {
    register_post_type('streamflow_stream', array(
        'labels' => array(
            'name' => __('Streams'),
            'singular_name' => __('Stream')
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'menu_icon' => 'dashicons-video-alt3'
    ));
}
add_action('init', 'streamflow_create_post_types');

// Add admin menu
function streamflow_admin_menu() {
    add_menu_page(
        'StreamFlow Settings',
        'StreamFlow',
        'manage_options',
        'streamflow-settings',
        'streamflow_settings_page',
        'dashicons-video-alt3',
        100
    );
    
    add_submenu_page(
        'streamflow-settings',
        'StreamFlow Settings',
        'Settings',
        'manage_options',
        'streamflow-settings',
        'streamflow_settings_page'
    );
    
    add_submenu_page(
        'streamflow-settings',
        'StreamFlow Streams',
        'Streams',
        'manage_options',
        'edit.php?post_type=streamflow_stream',
        null
    );
}
add_action('admin_menu', 'streamflow_admin_menu');

// Settings page
function streamflow_settings_page() {
    // Save settings
    if (isset($_POST['streamflow_save_settings'])) {
        check_admin_referer('streamflow_settings_nonce');
        
        update_option('streamflow_api_url', sanitize_text_field($_POST['streamflow_api_url']));
        update_option('streamflow_api_key', sanitize_text_field($_POST['streamflow_api_key']));
        update_option('streamflow_embed_width', sanitize_text_field($_POST['streamflow_embed_width']));
        update_option('streamflow_embed_height', sanitize_text_field($_POST['streamflow_embed_height']));
        
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully!</p></div>';
    }
    
    // Get current settings
    $api_url = get_option('streamflow_api_url', '');
    $api_key = get_option('streamflow_api_key', '');
    $embed_width = get_option('streamflow_embed_width', '100%');
    $embed_height = get_option('streamflow_embed_height', '480');
    
    // Display settings form
    ?>
    <div class="wrap">
        <h1>StreamFlow Settings</h1>
        
        <form method="post" action="">
            <?php wp_nonce_field('streamflow_settings_nonce'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="streamflow_api_url">StreamFlow API URL</label></th>
                    <td>
                        <input type="text" name="streamflow_api_url" id="streamflow_api_url" value="<?php echo esc_attr($api_url); ?>" class="regular-text">
                        <p class="description">Enter the URL of your StreamFlow server (e.g., https://your-streamflow-server.com)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="streamflow_api_key">API Key</label></th>
                    <td>
                        <input type="password" name="streamflow_api_key" id="streamflow_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text">
                        <p class="description">Enter your StreamFlow API key</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="streamflow_embed_width">Default Embed Width</label></th>
                    <td>
                        <input type="text" name="streamflow_embed_width" id="streamflow_embed_width" value="<?php echo esc_attr($embed_width); ?>" class="regular-text">
                        <p class="description">Enter the default width for embedded players (e.g., 100%, 640px)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="streamflow_embed_height">Default Embed Height</label></th>
                    <td>
                        <input type="text" name="streamflow_embed_height" id="streamflow_embed_height" value="<?php echo esc_attr($embed_height); ?>" class="regular-text">
                        <p class="description">Enter the default height for embedded players (e.g., 480)</p>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <input type="submit" name="streamflow_save_settings" class="button-primary" value="Save Settings">
            </p>
        </form>
    </div>
    <?php
}

// Register shortcode
function streamflow_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => '',
        'width' => get_option('streamflow_embed_width', '100%'),
        'height' => get_option('streamflow_embed_height', '480'),
        'autoplay' => 'false'
    ), $atts);
    
    if (empty($atts['id'])) {
        return '<p>Error: Stream ID is required.</p>';
    }
    
    $api_url = get_option('streamflow_api_url', '');
    if (empty($api_url)) {
        return '<p>Error: StreamFlow API URL not configured in settings.</p>';
    }
    
    // Build embed URL
    $embed_url = trailingslashit($api_url) . 'embed/' . $atts['id'];
    
    // Add autoplay parameter if needed
    if ($atts['autoplay'] === 'true') {
        $embed_url = add_query_arg('autoplay', 'true', $embed_url);
    }
    
    // Generate iframe
    $iframe = '<div class="streamflow-embed">';
    $iframe .= '<iframe src="' . esc_url($embed_url) . '" ';
    $iframe .= 'width="' . esc_attr($atts['width']) . '" ';
    $iframe .= 'height="' . esc_attr($atts['height']) . '" ';
    $iframe .= 'frameborder="0" allowfullscreen></iframe>';
    $iframe .= '</div>';
    
    // Add responsive styling
    $iframe .= '<style>
        .streamflow-embed {
            position: relative;
            max-width: 100%;
            height: auto;
        }
        .streamflow-embed iframe {
            max-width: 100%;
        }
    </style>';
    
    return $iframe;
}
add_shortcode('streamflow', 'streamflow_shortcode');

// Add StreamFlow button to TinyMCE
function streamflow_tinymce_button() {
    // Check user permissions
    if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
        return;
    }
    
    // Check if WYSIWYG is enabled
    if (get_user_option('rich_editing') !== 'true') {
        return;
    }
    
    // Add button to TinyMCE
    add_filter('mce_external_plugins', 'streamflow_add_tinymce_plugin');
    add_filter('mce_buttons', 'streamflow_register_tinymce_button');
}
add_action('admin_init', 'streamflow_tinymce_button');

// Add TinyMCE plugin
function streamflow_add_tinymce_plugin($plugin_array) {
    $plugin_array['streamflow'] = plugins_url('js/tinymce-plugin.js', __FILE__);
    return $plugin_array;
}

// Register TinyMCE button
function streamflow_register_tinymce_button($buttons) {
    array_push($buttons, 'streamflow');
    return $buttons;
}

// Add custom REST API endpoint to get streams
function streamflow_register_rest_routes() {
    register_rest_route('streamflow/v1', '/streams', array(
        'methods' => 'GET',
        'callback' => 'streamflow_get_streams',
        'permission_callback' => function () {
            return current_user_can('edit_posts');
        }
    ));
}
add_action('rest_api_init', 'streamflow_register_rest_routes');

// Get streams from StreamFlow API
function streamflow_get_streams() {
    $api_url = get_option('streamflow_api_url', '');
    $api_key = get_option('streamflow_api_key', '');
    
    if (empty($api_url)) {
        return new WP_Error('no_api_url', 'StreamFlow API URL not configured', array('status' => 400));
    }
    
    // Build request URL
    $request_url = trailingslashit($api_url) . 'api/streams';
    
    // Send request
    $response = wp_remote_get($request_url, array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key
        )
    ));
    
    if (is_wp_error($response)) {
        return new WP_Error('api_error', $response->get_error_message(), array('status' => 500));
    }
    
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        return new WP_Error('json_error', 'Invalid response from API', array('status' => 500));
    }
    
    return $data;
}

// Include TinyMCE plugin JS
function streamflow_enqueue_admin_scripts() {
    wp_enqueue_script('streamflow-admin', plugins_url('js/admin.js', __FILE__), array('jquery'), STREAMFLOW_VERSION, true);
    
    // Add localized data for JavaScript
    wp_localize_script('streamflow-admin', 'streamflow_data', array(
        'api_url' => get_option('streamflow_api_url', ''),
        'embed_width' => get_option('streamflow_embed_width', '100%'),
        'embed_height' => get_option('streamflow_embed_height', '480'),
        'rest_url' => rest_url('streamflow/v1/')
    ));
}
add_action('admin_enqueue_scripts', 'streamflow_enqueue_admin_scripts');

// Create directories for plugin assets
function streamflow_create_directories() {
    // Create js directory
    if (!file_exists(STREAMFLOW_PLUGIN_DIR . 'js')) {
        mkdir(STREAMFLOW_PLUGIN_DIR . 'js', 0755, true);
    }
}
register_activation_hook(__FILE__, 'streamflow_create_directories');

// Add a function to handle webhook callbacks from StreamFlow
function streamflow_webhook_callback() {
    if (!isset($_GET['streamflow_webhook'])) {
        return;
    }
    
    // Verify webhook signature
    $signature = isset($_SERVER['HTTP_X_STREAMFLOW_SIGNATURE']) ? $_SERVER['HTTP_X_STREAMFLOW_SIGNATURE'] : '';
    $api_key = get_option('streamflow_api_key', '');
    
    $payload = file_get_contents('php://input');
    $computed_signature = hash_hmac('sha256', $payload, $api_key);
    
    if (!hash_equals($computed_signature, $signature)) {
        status_header(403);
        die('Invalid signature');
    }
    
    // Process webhook payload
    $data = json_decode($payload, true);
    if (!$data || json_last_error() !== JSON_ERROR_NONE) {
        status_header(400);
        die('Invalid JSON payload');
    }
    
    // Process events
    if (isset($data['event'])) {
        switch ($data['event']) {
            case 'stream.started':
                // Handle stream started event
                streamflow_handle_stream_started($data);
                break;
                
            case 'stream.ended':
                // Handle stream ended event
                streamflow_handle_stream_ended($data);
                break;
                
            // Add more event handlers as needed
        }
    }
    
    status_header(200);
    die('OK');
}
add_action('init', 'streamflow_webhook_callback');

// Handle stream started event
function streamflow_handle_stream_started($data) {
    if (!isset($data['stream_id']) || !isset($data['stream_data'])) {
        return;
    }
    
    // Check if there's already a post for this stream
    $existing_posts = get_posts(array(
        'post_type' => 'streamflow_stream',
        'meta_key' => 'streamflow_stream_id',
        'meta_value' => $data['stream_id'],
        'posts_per_page' => 1
    ));
    
    if (!empty($existing_posts)) {
        // Update existing post
        $post_id = $existing_posts[0]->ID;
        wp_update_post(array(
            'ID' => $post_id,
            'post_status' => 'publish',
            'meta_input' => array(
                'streamflow_stream_status' => 'live'
            )
        ));
    } else {
        // Create new post
        $stream_data = $data['stream_data'];
        
        $post_id = wp_insert_post(array(
            'post_title' => isset($stream_data['title']) ? $stream_data['title'] : 'Untitled Stream',
            'post_content' => do_shortcode('[streamflow id="' . $data['stream_id'] . '"]') . "\n\n" . (isset($stream_data['description']) ? $stream_data['description'] : ''),
            'post_status' => 'publish',
            'post_type' => 'streamflow_stream',
            'meta_input' => array(
                'streamflow_stream_id' => $data['stream_id'],
                'streamflow_stream_status' => 'live',
                'streamflow_stream_owner' => isset($stream_data['owner']) ? $stream_data['owner'] : '',
                'streamflow_stream_started' => current_time('mysql')
            )
        ));
    }
}

// Handle stream ended event
function streamflow_handle_stream_ended($data) {
    if (!isset($data['stream_id'])) {
        return;
    }
    
    // Find the post for this stream
    $existing_posts = get_posts(array(
        'post_type' => 'streamflow_stream',
        'meta_key' => 'streamflow_stream_id',
        'meta_value' => $data['stream_id'],
        'posts_per_page' => 1
    ));
    
    if (!empty($existing_posts)) {
        $post_id = $existing_posts[0]->ID;
        
        // Update stream status
        update_post_meta($post_id, 'streamflow_stream_status', 'ended');
        update_post_meta($post_id, 'streamflow_stream_ended', current_time('mysql'));
    }
}