#!/bin/bash
echo "Installing StreamFlow dependencies..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is not installed. Please install Python 3 before continuing."
    exit 1
fi

# Update package lists
echo "Updating package lists..."
sudo apt update || { echo "Failed to update package lists. Please check your permissions."; exit 1; }

# Install FFmpeg
echo "Installing FFmpeg..."
sudo apt install -y ffmpeg || { echo "Failed to install FFmpeg. Continuing with other installations..."; }

# Install VLC
echo "Installing VLC..."
sudo apt install -y vlc || { echo "Failed to install VLC. Continuing with other installations..."; }

# Install Python packages
echo "Installing Python packages..."
pip install streamlit python-vlc ffmpeg-python pyyaml psutil || { echo "Failed to install Python packages. Please check your pip installation."; exit 1; }

# Create necessary directories
echo "Creating necessary directories..."
mkdir -p .streamlit || { echo "Failed to create .streamlit directory."; exit 1; }

# Create Streamlit configuration file if it doesn't exist
if [ ! -f .streamlit/config.toml ]; then
    echo "Creating Streamlit configuration file..."
    cat > .streamlit/config.toml << EOL
[server]
headless = true
address = "0.0.0.0"
port = 5000

[theme]
primaryColor = "#f63366"
backgroundColor = "#0e1117"
secondaryBackgroundColor = "#1a1c24"
textColor = "#fafafa"

[browser]
gatherUsageStats = false
EOL
fi

echo "Installation complete! You can now run the StreamFlow application with:"
echo "streamlit run app.py --server.port 5000"
echo ""
echo "Default admin account:"
echo "Username: admin"
echo "Password: admin"
echo ""
echo "Remember to change the default admin password after first login for security purposes."