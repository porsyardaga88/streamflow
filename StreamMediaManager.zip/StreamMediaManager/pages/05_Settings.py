import streamlit as st
from utils.session import init_session_state

# Initialize session state variables
init_session_state()
from utils.auth import require_auth
from utils.install import (
    check_dependencies, install_python_package,
    save_install_script, generate_install_script
)
import yaml
import os

# Set page configuration
st.set_page_config(
    page_title="Settings - StreamFlow",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Require authentication for this page
@require_auth
def main():
    st.title("User Settings")
    
    # Settings tabs
    tab1, tab2, tab3 = st.tabs(["Profile", "Appearance", "System Check"])
    
    with tab1:
        profile_settings()
    
    with tab2:
        appearance_settings()
    
    with tab3:
        system_check()

def profile_settings():
    """User profile settings"""
    st.subheader("Profile Settings")
    
    # Get current user
    username = st.session_state.username
    
    # Display username
    st.write(f"**Username:** {username}")
    
    # Change password form
    with st.expander("Change Password"):
        with st.form("change_password_form"):
            current_password = st.text_input("Current Password", type="password")
            new_password = st.text_input("New Password", type="password")
            confirm_password = st.text_input("Confirm New Password", type="password")
            
            if st.form_submit_button("Change Password"):
                if not current_password:
                    st.error("Current password is required")
                elif not new_password:
                    st.error("New password is required")
                elif new_password != confirm_password:
                    st.error("Passwords do not match")
                else:
                    # Verify current password
                    from utils.auth import hash_password
                    users = st.session_state.users
                    
                    if username in users:
                        stored_password = users[username]["password"]
                        hashed_input = hash_password(current_password)
                        
                        if stored_password == hashed_input:
                            # Update password
                            st.session_state.users[username]["password"] = hash_password(new_password)
                            st.success("Password changed successfully")
                        else:
                            st.error("Current password is incorrect")
    
    # Stream key management
    with st.expander("Manage Stream Key"):
        from utils.stream import get_stream_key, reset_stream_key
        
        # Get current stream key
        stream_key = get_stream_key(username)
        
        if stream_key:
            st.text_input("Your Stream Key", value=stream_key, disabled=True)
            
            if st.button("Reset Stream Key"):
                new_key = reset_stream_key(username)
                if new_key:
                    st.success("Stream key reset successfully")
                    st.rerun()
                else:
                    st.error("Failed to reset stream key")
        else:
            st.info("You don't have a stream key yet. One will be generated when you create a stream.")
    
    # Account stats
    with st.expander("Account Statistics"):
        from utils.media import get_user_media
        from utils.stream import get_user_streams
        
        # Get user's media items
        user_media = get_user_media()
        
        # Get user's streams
        user_streams = get_user_streams()
        
        # Display stats
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Media Items", len(user_media))
        
        with col2:
            st.metric("Streams", len(user_streams))
        
        with col3:
            # Calculate total views
            total_views = sum(item.get('views', 0) for item in user_media)
            st.metric("Total Views", total_views)
        
        # Media breakdown
        if user_media:
            st.subheader("Media Breakdown")
            
            # Count by type
            from utils.media import VIDEO, AUDIO, LIVE
            video_count = sum(1 for item in user_media if item.get('type') == VIDEO)
            audio_count = sum(1 for item in user_media if item.get('type') == AUDIO)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("Videos", video_count)
            
            with col2:
                st.metric("Audio", audio_count)
            
            # Top viewed media
            st.subheader("Most Viewed Media")
            
            # Sort by views
            top_media = sorted(user_media, key=lambda x: x.get('views', 0), reverse=True)[:5]
            
            for item in top_media:
                st.write(f"{item.get('title', 'Untitled')} - {item.get('views', 0)} views")

def appearance_settings():
    """User interface and appearance settings"""
    st.subheader("Appearance Settings")
    
    # Load user preferences
    if 'user_preferences' not in st.session_state:
        st.session_state.user_preferences = {}
    
    preferences = st.session_state.user_preferences.get(st.session_state.username, {})
    
    # Default preferences
    if not preferences:
        preferences = {
            'default_page': 'Media Player',
            'player_volume': 80,
            'auto_play': False,
            'notifications': True
        }
    
    # Update preferences
    with st.form("appearance_settings_form"):
        # Default page
        default_page = st.selectbox(
            "Default Page",
            ['Media Player', 'My Library', 'Stream Setup'],
            index=['Media Player', 'My Library', 'Stream Setup'].index(preferences.get('default_page', 'Media Player'))
        )
        
        # Player settings
        st.subheader("Player Settings")
        player_volume = st.slider("Default Volume", 0, 100, preferences.get('player_volume', 80))
        auto_play = st.checkbox("Auto-play media", value=preferences.get('auto_play', False))
        
        # Notification settings
        st.subheader("Notification Settings")
        notifications = st.checkbox("Enable notifications", value=preferences.get('notifications', True))
        
        # Save button
        if st.form_submit_button("Save Preferences"):
            # Update preferences
            preferences.update({
                'default_page': default_page,
                'player_volume': player_volume,
                'auto_play': auto_play,
                'notifications': notifications
            })
            
            # Save to session state
            if 'user_preferences' not in st.session_state:
                st.session_state.user_preferences = {}
            
            st.session_state.user_preferences[st.session_state.username] = preferences
            
            st.success("Preferences saved successfully")
    
    # Reset to defaults
    if st.button("Reset to Defaults"):
        # Clear preferences
        if 'user_preferences' in st.session_state and st.session_state.username in st.session_state.user_preferences:
            del st.session_state.user_preferences[st.session_state.username]
        
        st.success("Preferences reset to defaults")
        st.rerun()

def system_check():
    """System dependency check and installation"""
    st.subheader("System Check")
    
    # Check dependencies
    dependencies = check_dependencies()
    
    # Display dependency status
    for dep, status in dependencies.items():
        col1, col2, col3 = st.columns([2, 1, 3])
        
        col1.write(dep)
        
        if status['installed']:
            col2.success("Installed")
            col3.write(f"Version: {status['version']}")
        else:
            col2.error("Not Installed")
            
            # Show install button for Python packages
            if dep in ['python-vlc', 'ffmpeg-python']:
                if col3.button(f"Install {dep}", key=f"install_{dep}"):
                    success, message = install_python_package(dep)
                    if success:
                        st.success(message)
                        st.rerun()
                    else:
                        st.error(message)
            else:
                col3.code(status['install_cmd'])
    
    # Generate installation script
    st.subheader("Installation Script")
    
    st.write("Generate an installation script for all required dependencies:")
    
    if st.button("Generate Installation Script"):
        script_content = generate_install_script()
        st.code(script_content, language="bash")
        
        # Option to save script
        if st.button("Save Script to File"):
            filename = save_install_script()
            st.success(f"Installation script saved as '{filename}'")
            
            # Provide download link
            with open(filename, 'r') as f:
                script_content = f.read()
            
            st.download_button(
                label="Download Script",
                data=script_content,
                file_name=filename,
                mime="text/plain"
            )

if __name__ == "__main__":
    main()
