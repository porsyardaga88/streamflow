import streamlit as st
from utils.session import init_session_state

# Initialize session state variables
init_session_state()
from utils.auth import require_auth
from utils.wordpress import (
    initialize_wordpress, save_wordpress_settings,
    get_wordpress_settings, create_wordpress_template,
    update_wordpress_template, delete_wordpress_template,
    get_wordpress_templates, get_wordpress_template,
    render_template, create_wordpress_post,
    publish_wordpress_post, delete_wordpress_post,
    get_wordpress_posts, get_wordpress_post,
    generate_wordpress_plugin_code
)
from utils.stream import get_user_streams

# Set page configuration
st.set_page_config(
    page_title="WordPress Integration - StreamFlow",
    page_icon="🔌",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize WordPress functionality
initialize_wordpress()

# Require authentication for this page
@require_auth
def main():
    st.title("WordPress Integration")
    
    # Tabs for different WordPress integration features
    tab1, tab2, tab3, tab4 = st.tabs(["Settings", "Templates", "Posts", "Plugin"])
    
    with tab1:
        wordpress_settings()
    
    with tab2:
        wordpress_templates()
    
    with tab3:
        wordpress_posts()
    
    with tab4:
        wordpress_plugin()

def wordpress_settings():
    """WordPress connection settings"""
    st.subheader("WordPress Connection Settings")
    
    # Get current settings
    settings = get_wordpress_settings()
    
    with st.form("wordpress_settings_form"):
        # Enable/disable integration
        enabled = st.checkbox("Enable WordPress Integration", value=settings.get('enabled', False))
        
        # WordPress site URL
        site_url = st.text_input("WordPress Site URL", value=settings.get('site_url', ''),
                                placeholder="https://your-wordpress-site.com")
        
        # WordPress authentication
        st.subheader("Authentication")
        username = st.text_input("WordPress Username", value=settings.get('username', ''))
        app_password = st.text_input("Application Password", 
                                   value=settings.get('application_password', ''),
                                   type="password",
                                   help="Create an application password in your WordPress user profile")
        
        # Post settings
        st.subheader("Post Settings")
        default_category = st.text_input("Default Category", value=settings.get('default_category', 'streaming'))
        auto_publish = st.checkbox("Auto-publish posts", value=settings.get('auto_publish', False))
        
        # Save button
        if st.form_submit_button("Save Settings"):
            # Update settings
            save_wordpress_settings({
                'enabled': enabled,
                'site_url': site_url,
                'username': username,
                'application_password': app_password,
                'default_category': default_category,
                'auto_publish': auto_publish
            })
            
            st.success("WordPress settings saved successfully")
    
    # Connection test
    if settings.get('enabled', False) and settings.get('site_url', '') and settings.get('username', ''):
        if st.button("Test Connection"):
            # In a real implementation, this would make an actual API call to WordPress
            # For this MVP, we'll simulate the connection test
            if settings.get('site_url', '').startswith(('http://', 'https://')) and settings.get('application_password', ''):
                st.success("Connection successful! WordPress integration is working.")
            else:
                st.error("Connection failed. Please check your settings.")

def wordpress_templates():
    """WordPress post templates management"""
    st.subheader("WordPress Post Templates")
    
    # Get all templates
    templates = get_wordpress_templates()
    
    # Display existing templates
    for template_id, template in templates.items():
        with st.expander(f"{template['name']} Template", expanded=False):
            # Template preview
            st.code(template['content'])
            
            # Edit button
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("Edit Template", key=f"edit_{template_id}"):
                    st.session_state.edit_template_id = template_id
                    st.rerun()
            
            # Delete button (only for custom templates)
            with col2:
                if template_id not in ['default', 'minimal']:
                    if st.button("Delete Template", key=f"delete_{template_id}"):
                        if delete_wordpress_template(template_id):
                            st.success(f"Template '{template['name']}' deleted")
                            st.rerun()
                        else:
                            st.error("Failed to delete template")
    
    # Add new template button
    if st.button("Create New Template"):
        st.session_state.creating_template = True
        st.rerun()
    
    # Template editing form
    if hasattr(st.session_state, 'edit_template_id'):
        template_id = st.session_state.edit_template_id
        template = get_wordpress_template(template_id)
        
        if template:
            st.subheader(f"Edit Template: {template['name']}")
            
            with st.form("edit_template_form"):
                name = st.text_input("Template Name", value=template['name'])
                content = st.text_area("Template Content", value=template['content'], height=300)
                
                st.markdown("""
                **Available Placeholders:**
                - `{title}` - Stream title
                - `{description}` - Stream description
                - `{stream_key}` - Stream key
                - `{username}` - Username of stream owner
                - `{start_time}` - Stream start time
                - `{stream_id}` - Stream ID
                """)
                
                if st.form_submit_button("Save Template"):
                    if update_wordpress_template(template_id, name, content):
                        st.success("Template updated successfully")
                        del st.session_state.edit_template_id
                        st.rerun()
                    else:
                        st.error("Failed to update template")
            
            if st.button("Cancel Editing"):
                del st.session_state.edit_template_id
                st.rerun()
    
    # Create new template form
    if hasattr(st.session_state, 'creating_template'):
        st.subheader("Create New Template")
        
        with st.form("create_template_form"):
            name = st.text_input("Template Name")
            content = st.text_area("Template Content", height=300, placeholder="""
<!-- StreamFlow Player Embed -->
[streamflow_player stream="{stream_key}" width="640" height="360"]

<h2>{title}</h2>
<p>{description}</p>

<p>Stream started: {start_time}</p>
<p>Streamed by: {username}</p>
            """)
            
            st.markdown("""
            **Available Placeholders:**
            - `{title}` - Stream title
            - `{description}` - Stream description
            - `{stream_key}` - Stream key
            - `{username}` - Username of stream owner
            - `{start_time}` - Stream start time
            - `{stream_id}` - Stream ID
            """)
            
            if st.form_submit_button("Create Template"):
                if name and content:
                    template_id = create_wordpress_template(name, content)
                    st.success(f"Template '{name}' created successfully")
                    del st.session_state.creating_template
                    st.rerun()
                else:
                    st.error("Template name and content are required")
        
        if st.button("Cancel"):
            del st.session_state.creating_template
            st.rerun()

def wordpress_posts():
    """WordPress posts management"""
    st.subheader("WordPress Posts")
    
    # Check if WordPress integration is enabled
    settings = get_wordpress_settings()
    if not settings.get('enabled', False):
        st.warning("WordPress integration is not enabled. Please enable it in the Settings tab.")
        return
    
    # Get WordPress posts
    posts = get_wordpress_posts()
    
    # Create new post section
    with st.expander("Create New WordPress Post", expanded=False):
        # Get user's streams
        streams = get_user_streams()
        
        if not streams:
            st.info("You don't have any streams. Create a stream first.")
        else:
            # Create post form
            with st.form("create_post_form"):
                # Select stream
                stream_options = {stream_id: stream_info.get('title', 'Untitled Stream') 
                                for stream_id, stream_info in streams.items()}
                selected_stream = st.selectbox("Select Stream", list(stream_options.keys()),
                                             format_func=lambda x: stream_options[x])
                
                # Post title
                post_title = st.text_input("Post Title", 
                                         value=streams[selected_stream].get('title', 'Untitled Stream'))
                
                # Select template
                templates = get_wordpress_templates()
                template_options = {template_id: template['name'] for template_id, template in templates.items()}
                selected_template = st.selectbox("Select Template", list(template_options.keys()),
                                               format_func=lambda x: template_options[x])
                
                # Category
                category = st.text_input("Category", value=settings.get('default_category', 'streaming'))
                
                # Auto-publish
                auto_publish = st.checkbox("Publish immediately", value=settings.get('auto_publish', False))
                
                # Create post button
                if st.form_submit_button("Create Post"):
                    post_id, error = create_wordpress_post(
                        stream_id=selected_stream,
                        template_id=selected_template,
                        title=post_title,
                        category=category
                    )
                    
                    if post_id:
                        if auto_publish:
                            publish_wordpress_post(post_id)
                            st.success("WordPress post created and published successfully")
                        else:
                            st.success("WordPress post created successfully as draft")
                        st.rerun()
                    else:
                        st.error(f"Failed to create post: {error}")
    
    # Existing posts
    if not posts:
        st.info("No WordPress posts have been created yet.")
    else:
        st.write(f"Existing Posts ({len(posts)})")
        
        for post in posts:
            with st.expander(f"{post.get('title', 'Untitled Post')}", expanded=False):
                # Post details
                st.write(f"**Status:** {post.get('status', 'draft').title()}")
                st.write(f"**Category:** {post.get('category', 'Uncategorized')}")
                st.write(f"**Created:** {post.get('created_at', 'Unknown')}")
                
                # Preview content
                st.subheader("Content Preview")
                st.code(post.get('content', ''), language="html")
                
                # Action buttons
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    # Publish/Unpublish button
                    if post.get('status', 'draft') == 'draft':
                        if st.button("Publish", key=f"publish_{post['id']}"):
                            if publish_wordpress_post(post['id']):
                                st.success("Post published successfully")
                                st.rerun()
                            else:
                                st.error("Failed to publish post")
                
                with col2:
                    # Delete button
                    if st.button("Delete", key=f"delete_post_{post['id']}"):
                        if delete_wordpress_post(post['id']):
                            st.success("Post deleted successfully")
                            st.rerun()
                        else:
                            st.error("Failed to delete post")
                
                with col3:
                    # View on WordPress button (simulated for MVP)
                    if st.button("View on WordPress", key=f"view_{post['id']}"):
                        wordpress_url = settings.get('site_url', '')
                        if wordpress_url:
                            st.info(f"This would open: {wordpress_url}/p/{post.get('wordpress_id', 'unknown')}")
                            st.warning("This is a simulation. In a real implementation, this would open the actual WordPress post.")
                        else:
                            st.error("WordPress site URL is not configured")

def wordpress_plugin():
    """WordPress plugin code and installation instructions"""
    st.subheader("WordPress Plugin")
    
    st.write("""
    To use StreamFlow with WordPress, you need to install the StreamFlow WordPress plugin. 
    This will allow you to embed streams and media directly in your WordPress posts and pages.
    """)
    
    # Plugin installation instructions
    with st.expander("Installation Instructions"):
        st.markdown("""
        ### Installation Steps
        
        1. Download the plugin code below
        2. In your WordPress admin panel, go to Plugins > Add New
        3. Click the "Upload Plugin" button
        4. Choose the downloaded file and click "Install Now"
        5. After installation, click "Activate Plugin"
        6. Go to StreamFlow settings in your WordPress admin menu
        7. Configure the StreamFlow URL to point to your StreamFlow instance
        
        ### Using the Plugin
        
        Once installed, you can use the following shortcode in your posts and pages:
        
        ```
        [streamflow_player stream="YOUR_STREAM_KEY" width="640" height="360" autoplay="false"]
        ```
        
        Parameters:
        - `stream` (required): Your StreamFlow stream key
        - `width` (optional): Player width in pixels or percentage (default: 640)
        - `height` (optional): Player height in pixels (default: 360)
        - `autoplay` (optional): Set to "true" to enable autoplay (default: false)
        """)
    
    # Plugin code
    st.subheader("Plugin Code")
    
    plugin_code = generate_wordpress_plugin_code()
    st.code(plugin_code, language="php")
    
    # Download button (simulated for MVP)
    if st.button("Download Plugin"):
        st.download_button(
            label="Download StreamFlow WordPress Plugin",
            data=plugin_code,
            file_name="streamflow-wordpress-plugin.php",
            mime="text/php"
        )

if __name__ == "__main__":
    main()
