import streamlit as st
from utils.auth import require_auth
from utils.stream import (
    initialize_streaming, create_stream, get_stream_info,
    get_user_streams, start_stream, stop_stream, delete_stream,
    get_stream_key, reset_stream_key, get_streaming_instructions,
    generate_embed_code, is_ffmpeg_installed, is_vlc_installed
)
from utils.session import init_session_state

# Initialize session state variables
init_session_state()

# Set page configuration
st.set_page_config(
    page_title="Stream Setup - StreamFlow",
    page_icon="📹",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize streaming functionality
initialize_streaming()

# Require authentication for this page
@require_auth
def main():
    st.title("Stream Setup")
    
    # Check if the current stream ID is set in session state
    current_stream_id = None
    if hasattr(st.session_state, 'current_stream_id'):
        current_stream_id = st.session_state.current_stream_id
        # Clear it so it's not used again
        del st.session_state.current_stream_id
    
    # Get user's streams
    user_streams = get_user_streams()
    
    # Tabs for different stream setup options
    tab1, tab2, tab3 = st.tabs(["My Streams", "Create New Stream", "Stream Key"])
    
    with tab1:
        display_user_streams(user_streams, current_stream_id)
    
    with tab2:
        create_new_stream()
    
    with tab3:
        manage_stream_key()

def display_user_streams(user_streams, current_stream_id=None):
    """Display user's existing streams"""
    st.subheader("My Streams")
    
    if not user_streams:
        st.info("You don't have any streams set up yet. Create a new stream to get started.")
        return
    
    # If a specific stream should be displayed, show it first and expanded
    if current_stream_id and current_stream_id in user_streams:
        display_stream_details(current_stream_id, user_streams[current_stream_id], expanded=True)
        
        # Display other streams collapsed
        for stream_id, stream_info in user_streams.items():
            if stream_id != current_stream_id:
                display_stream_details(stream_id, stream_info, expanded=False)
    else:
        # Display all streams
        for stream_id, stream_info in user_streams.items():
            display_stream_details(stream_id, stream_info, expanded=False)

def display_stream_details(stream_id, stream_info, expanded=False):
    """Display details and controls for a single stream"""
    with st.expander(f"{stream_info.get('title', 'Untitled Stream')}", expanded=expanded):
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.write(f"**Description:** {stream_info.get('description', 'No description')}")
            st.write(f"**Type:** {stream_info.get('type', 'Unknown')}")
            
            # Stream status
            status = stream_info.get('status', 'idle')
            if status == 'active':
                st.success("Stream is currently ACTIVE")
            elif status == 'error':
                st.error(f"Stream Error: {stream_info.get('last_error', 'Unknown error')}")
            else:
                st.info("Stream is currently IDLE")
            
            # Stream key
            st.text_input("Stream Key", value=stream_info.get('stream_key', ''), disabled=True, 
                         type="password", help="Use this key in your streaming software")
            
            # Stream management buttons
            if status == 'active':
                if st.button("Stop Stream", key=f"stop_{stream_id}"):
                    if stop_stream(stream_id):
                        st.success("Stream stopped successfully")
                        st.rerun()
                    else:
                        st.error("Failed to stop stream")
            else:
                if st.button("Start Stream", key=f"start_{stream_id}"):
                    if start_stream(stream_id):
                        st.success("Stream started successfully")
                        st.rerun()
                    else:
                        st.error("Failed to start stream")
            
            # Delete stream button
            if st.button("Delete Stream", key=f"delete_{stream_id}"):
                if delete_stream(stream_id):
                    st.success("Stream deleted successfully")
                    st.rerun()
                else:
                    st.error("Failed to delete stream")
        
        with col2:
            # Stream settings and visibility
            is_public = stream_info.get('is_public', False)
            new_is_public = st.checkbox("Public Stream", value=is_public, key=f"public_{stream_id}")
            
            if new_is_public != is_public:
                # Update stream visibility
                stream_info['is_public'] = new_is_public
                st.success("Visibility updated")
            
            # Show viewers if active
            if status == 'active':
                st.metric("Current Viewers", stream_info.get('viewers', 0))
        
        # Streaming instructions
        st.subheader("Streaming Instructions")
        
        instructions = get_streaming_instructions(stream_id)
        if instructions:
            # Tabs for different streaming methods
            inst_tab1, inst_tab2, inst_tab3 = st.tabs(["OBS", "FFmpeg", "VLC"])
            
            with inst_tab1:
                st.write("**OBS Studio Settings**")
                st.code(f"""
Server: {instructions['rtmp']['obs_settings']['server']}
Stream Key: {instructions['rtmp']['obs_settings']['stream_key']}
Service: Custom
""")
                st.write("Recommended Output Settings:")
                st.write("- Video Bitrate: 2500-4000 Kbps")
                st.write("- Audio Bitrate: 128-192 Kbps")
                st.write("- Keyframe Interval: 2 seconds")
            
            with inst_tab2:
                st.write("**FFmpeg Command**")
                if is_ffmpeg_installed():
                    st.code(instructions['rtmp']['ffmpeg_cmd'])
                else:
                    st.warning("FFmpeg is not installed. Install it to use this streaming method.")
                    st.write("Replace [INPUT] with your input file or device")
            
            with inst_tab3:
                st.write("**VLC Command**")
                if is_vlc_installed():
                    st.code(instructions['vlc']['cmd'])
                else:
                    st.warning("VLC is not installed. Install it to use this streaming method.")
                    st.write("Replace [INPUT] with your input file or device")
        
        # Embed options
        st.subheader("Embed Options")
        
        embed_codes = generate_embed_code(stream_id)
        if embed_codes:
            embed_tab1, embed_tab2 = st.tabs(["iFrame Embed", "WordPress Shortcode"])
            
            with embed_tab1:
                st.code(embed_codes['iframe'])
                st.write("Copy this code to embed the stream in a website")
            
            with embed_tab2:
                st.code(embed_codes['shortcode'])
                st.write("Use this shortcode in WordPress with the StreamFlow plugin")
        
        # Option to create WordPress post if integration is enabled
        if 'wordpress_settings' in st.session_state and st.session_state.wordpress_settings.get('enabled', False):
            st.subheader("WordPress Integration")
            
            if st.button("Create WordPress Post", key=f"wp_{stream_id}"):
                # Import WordPress functions
                from utils.wordpress import create_wordpress_post, get_wordpress_templates
                
                # Get templates
                templates = get_wordpress_templates()
                template_id = "default"  # Default template
                
                # Create post
                post_id, error = create_wordpress_post(stream_id, template_id=template_id)
                
                if post_id:
                    st.success("WordPress post created successfully")
                    # Option to go to WordPress integration page
                    if st.button("Go to WordPress Integration"):
                        st.switch_page("pages/06_WordPress_Integration.py")
                else:
                    st.error(f"Failed to create WordPress post: {error}")

def create_new_stream():
    """Form for creating a new stream"""
    st.subheader("Create New Stream")
    
    with st.form("create_stream_form"):
        # Stream details
        title = st.text_input("Stream Title")
        description = st.text_area("Stream Description")
        
        # Stream type
        stream_type = st.selectbox("Stream Type", ["rtmp", "vlc"])
        
        # Stream visibility
        is_public = st.checkbox("Public Stream", value=True)
        
        # Submit button
        submit = st.form_submit_button("Create Stream")
        
        if submit:
            if not title:
                st.error("Stream title is required")
            else:
                # Create stream
                stream_id, error = create_stream(
                    title=title,
                    description=description,
                    stream_type=stream_type,
                    is_public=is_public
                )
                
                if stream_id:
                    st.success(f"Stream created successfully!")
                    
                    # Set current stream ID to show details
                    st.session_state.current_stream_id = stream_id
                    st.rerun()
                else:
                    st.error(f"Failed to create stream: {error}")

def manage_stream_key():
    """Manage user's stream key"""
    st.subheader("Your Stream Key")
    
    # Get current stream key
    username = st.session_state.username
    stream_key = get_stream_key(username)
    
    if stream_key:
        st.write("Your personal stream key can be used across multiple streams.")
        st.text_input("Stream Key", value=stream_key, disabled=True, type="password")
        
        # Option to reset stream key
        if st.button("Reset Stream Key", help="Warning: This will invalidate any existing streams using this key"):
            new_key = reset_stream_key(username)
            if new_key:
                st.success("Stream key reset successfully")
                st.rerun()
            else:
                st.error("Failed to reset stream key")
    else:
        st.warning("You don't have a stream key yet. Create a stream to generate one.")

if __name__ == "__main__":
    main()
