import streamlit as st
import yaml
import os
from datetime import datetime
from utils.auth import (
    require_admin, get_all_users, approve_user,
    change_user_role, delete_user
)
from utils.stream import get_stream_stats
from utils.media import get_public_media
from utils.session import init_session_state

# Initialize session state variables
init_session_state()

# Set page configuration
st.set_page_config(
    page_title="Admin Dashboard - StreamFlow",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Access configuration
st.set_page_config.accessed_directly = True

# Custom admin access check that adds a direct URL note
def admin_access_check():
    """Check if user is admin and provide direct URL access information"""
    # Check if admin
    if not st.session_state.get('is_admin', False):
        st.error("Access Denied: You must be an admin to view this page.")
        
        # Load config to check for custom admin URL path if it exists
        custom_admin_path = None
        if os.path.exists('config.yaml'):
            with open('config.yaml', 'r') as file:
                config = yaml.safe_load(file)
                # Check if custom admin path is configured
                custom_admin_path = config.get('auth', {}).get('admin_dashboard_path', None)
        
        # Display the appropriate access info
        if custom_admin_path:
            st.info(f"If you are an admin, you can access this dashboard at: {custom_admin_path}")
        else:
            st.info("If you are an admin, you can access this dashboard directly at: /streamlit/pages/04_Admin_Dashboard.py")
        st.stop()
    
    # If we've come this far, the user is an admin
    # Load config to check for custom admin URL path if it exists
    custom_admin_path = None
    if os.path.exists('config.yaml'):
        with open('config.yaml', 'r') as file:
            config = yaml.safe_load(file)
            # Check if custom admin path is configured
            custom_admin_path = config.get('auth', {}).get('admin_dashboard_path', None)
    
    if not getattr(st.set_page_config, 'accessed_directly', False):
        if custom_admin_path:
            st.info(f"Admin tip: You can access this dashboard directly at: {custom_admin_path}")
        else:
            st.info("Admin tip: You can access this dashboard directly at: /streamlit/pages/04_Admin_Dashboard.py")
    
    return True

# Check admin access before proceeding
admin_access_check()

def main():
    st.title("Admin Dashboard")
    
    # Overview metrics at the top
    display_overview_metrics()
    
    # Admin tabs
    tab1, tab2, tab3, tab4 = st.tabs(["Users", "Streams", "System", "Settings"])
    
    with tab1:
        manage_users()
    
    with tab2:
        monitor_streams()
    
    with tab3:
        system_status()
    
    with tab4:
        app_settings()

def display_overview_metrics():
    """Display overview metrics at the top of the dashboard"""
    # Get user count
    user_count = len(get_all_users())
    
    # Get active streams count and viewer count
    stream_stats = get_stream_stats()
    active_streams = len(stream_stats)
    total_viewers = sum(s.get('viewers', 0) for s in stream_stats.values())
    
    # Get media count
    media_count = len(get_public_media())
    
    # Display metrics in columns
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Users", user_count)
    
    with col2:
        st.metric("Active Streams", active_streams)
    
    with col3:
        st.metric("Current Viewers", total_viewers)
    
    with col4:
        st.metric("Media Items", media_count)

def manage_users():
    """User management section"""
    st.subheader("User Management")
    
    # Get all users
    users = get_all_users()
    
    if not users:
        st.info("No users found.")
        return
    
    # User search and filter
    search_query = st.text_input("Search Users", placeholder="Enter username...")
    role_filter = st.selectbox("Filter by Role", ["All", "admin", "user"])
    approval_filter = st.selectbox("Filter by Approval Status", ["All", "Approved", "Pending"])
    
    # Apply filters
    filtered_users = {}
    for username, user_data in users.items():
        # Apply search filter
        if search_query and search_query.lower() not in username.lower():
            continue
        
        # Apply role filter
        if role_filter != "All" and user_data.get("role") != role_filter:
            continue
        
        # Apply approval filter
        is_approved = user_data.get("approved", False)
        if approval_filter == "Approved" and not is_approved:
            continue
        elif approval_filter == "Pending" and is_approved:
            continue
        
        # Add to filtered users
        filtered_users[username] = user_data
    
    # Display user list
    st.write(f"Showing {len(filtered_users)} users")
    
    # Table header
    col1, col2, col3, col4, col5 = st.columns([2, 1, 1, 1, 2])
    col1.write("**Username**")
    col2.write("**Role**")
    col3.write("**Status**")
    col4.write("**Created**")
    col5.write("**Actions**")
    
    st.markdown("---")
    
    # Table rows
    for username, user_data in filtered_users.items():
        col1, col2, col3, col4, col5 = st.columns([2, 1, 1, 1, 2])
        
        # Username
        col1.write(username)
        
        # Role
        role = user_data.get("role", "user")
        col2.write(role)
        
        # Approval status
        is_approved = user_data.get("approved", False)
        if is_approved:
            col3.success("Approved")
        else:
            col3.warning("Pending")
        
        # Created at
        created_at = user_data.get("created_at", "Unknown")
        if isinstance(created_at, str):
            try:
                # Convert ISO format to datetime
                dt = datetime.fromisoformat(created_at)
                # Format as date only
                created_at = dt.strftime("%Y-%m-%d")
            except:
                pass
        col4.write(created_at)
        
        # Actions
        with col5:
            # Approve button
            if not is_approved:
                if st.button("Approve", key=f"approve_{username}"):
                    if approve_user(username):
                        st.success(f"User {username} approved")
                        st.rerun()
                    else:
                        st.error("Failed to approve user")
            
            # Change role button
            new_role = "admin" if role == "user" else "user"
            if st.button(f"Make {new_role.title()}", key=f"role_{username}"):
                if change_user_role(username, new_role):
                    st.success(f"User {username} is now {new_role}")
                    st.rerun()
                else:
                    st.error("Failed to change user role")
            
            # Delete button
            if st.button("Delete", key=f"delete_{username}"):
                # Confirm deletion
                st.warning(f"Are you sure you want to delete user {username}?")
                if st.button("Confirm Delete", key=f"confirm_{username}"):
                    if delete_user(username):
                        st.success(f"User {username} deleted")
                        st.rerun()
                    else:
                        st.error("Failed to delete user")
        
        st.markdown("---")

def monitor_streams():
    """Stream monitoring section"""
    st.subheader("Stream Monitoring")
    
    # Get active streams
    stream_stats = get_stream_stats()
    
    if not stream_stats:
        st.info("No active streams.")
        return
    
    # Display active streams
    st.write(f"Active Streams: {len(stream_stats)}")
    
    # Table header
    col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
    col1.write("**Stream Title**")
    col2.write("**Owner**")
    col3.write("**Viewers**")
    col4.write("**Started**")
    
    st.markdown("---")
    
    # Table rows
    for stream_id, stats in stream_stats.items():
        col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
        
        # Title
        col1.write(stats.get("title", "Untitled"))
        
        # Owner
        col2.write(stats.get("owner", "Unknown"))
        
        # Viewers
        col3.metric("", stats.get("viewers", 0))
        
        # Started at
        started_at = stats.get("started_at", "Unknown")
        if isinstance(started_at, str):
            try:
                # Convert ISO format to datetime
                dt = datetime.fromisoformat(started_at)
                # Calculate duration
                duration = datetime.now() - dt
                # Format as HH:MM:SS
                hours, remainder = divmod(duration.seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                started_at = f"{hours:02d}:{minutes:02d}:{seconds:02d} ago"
            except:
                pass
        col4.write(started_at)
        
        st.markdown("---")
    
    # Auto-refresh option
    st.checkbox("Auto-refresh (10s)", key="auto_refresh_streams")
    if st.session_state.get("auto_refresh_streams", False):
        # Add auto-refresh using JavaScript
        st.markdown("""
        <script>
            setTimeout(function() {
                window.location.reload();
            }, 10000);
        </script>
        """, unsafe_allow_html=True)

def system_status():
    """System status and information section"""
    st.subheader("System Status")
    
    # Check dependencies
    from utils.install import check_dependencies
    
    st.write("Dependency Status")
    dependencies = check_dependencies()
    
    for dep, status in dependencies.items():
        col1, col2, col3 = st.columns([2, 1, 3])
        
        col1.write(dep)
        
        if status['installed']:
            col2.success("Installed")
            col3.write(f"Version: {status['version']}")
        else:
            col2.error("Not Installed")
            col3.code(status['install_cmd'])
    
    # System information
    st.subheader("System Information")
    
    import platform
    import psutil
    
    # Platform info
    st.write(f"Platform: {platform.platform()}")
    st.write(f"Python Version: {platform.python_version()}")
    
    # CPU usage
    cpu_percent = psutil.cpu_percent()
    st.metric("CPU Usage", f"{cpu_percent}%")
    
    # Memory usage
    memory = psutil.virtual_memory()
    memory_used_gb = memory.used / (1024**3)
    memory_total_gb = memory.total / (1024**3)
    st.metric("Memory Usage", f"{memory_used_gb:.1f} GB / {memory_total_gb:.1f} GB ({memory.percent}%)")
    
    # Disk usage
    disk = psutil.disk_usage('/')
    disk_used_gb = disk.used / (1024**3)
    disk_total_gb = disk.total / (1024**3)
    st.metric("Disk Usage", f"{disk_used_gb:.1f} GB / {disk_total_gb:.1f} GB ({disk.percent}%)")

def app_settings():
    """Application settings section"""
    st.subheader("Application Settings")
    
    # Load configuration
    if os.path.exists('config.yaml'):
        with open('config.yaml', 'r') as file:
            config = yaml.safe_load(file)
    else:
        config = {
            'site_name': 'StreamFlow',
            'allow_registration': True,
            'require_approval': False,
            'rtmp_server': 'rtmp://localhost/live',
            'default_player': 'vlc'
        }
    
    # Edit configuration
    with st.form("app_settings_form"):
        # General settings
        st.write("**General Settings**")
        # Support both new and old config formats
        site_name = st.text_input("Site Name", value=config.get('site_name', config.get('app', {}).get('name', 'StreamFlow')))
        
        # Security settings
        st.write("**Security Settings**")
        
        # Get the current auth settings, handling nested config if present
        auth_config = config.get('auth', {})
        
        # Admin dashboard path setting
        current_admin_path = auth_config.get('admin_dashboard_path', '/streamlit/pages/04_Admin_Dashboard.py')
        admin_dashboard_path = st.text_input(
            "Admin Dashboard URL Path", 
            value=current_admin_path,
            help="Customize the URL path to access the admin dashboard. Default is '/streamlit/pages/04_Admin_Dashboard.py'"
        )
        
        # User settings
        st.write("**User Settings**")
        allow_registration = st.checkbox(
            "Allow Registration", 
            value=config.get('allow_registration', auth_config.get('allow_registration', True))
        )
        require_approval = st.checkbox(
            "Require Admin Approval for New Users", 
            value=config.get('require_approval', auth_config.get('require_admin_approval', False))
        )
        
        # Streaming settings
        st.write("**Streaming Settings**")
        streaming_config = config.get('streaming', {})
        rtmp_server = st.text_input(
            "RTMP Server URL", 
            value=config.get('rtmp_server', streaming_config.get('rtmp_server', 'rtmp://localhost/live'))
        )
        default_player = st.selectbox(
            "Default Player", 
            ['vlc', 'html5'], 
            index=0 if config.get('default_player', streaming_config.get('default_player', 'vlc')) == 'vlc' else 1
        )
        
        # Save button
        if st.form_submit_button("Save Settings"):
            # Create updated config, preserving the structure
            updated_config = config.copy()
            
            # Update app section
            if 'app' not in updated_config:
                updated_config['app'] = {}
            updated_config['app']['name'] = site_name
            
            # Update auth section
            if 'auth' not in updated_config:
                updated_config['auth'] = {}
            updated_config['auth']['allow_registration'] = allow_registration
            updated_config['auth']['require_admin_approval'] = require_approval
            updated_config['auth']['admin_dashboard_path'] = admin_dashboard_path
            
            # Update streaming section
            if 'streaming' not in updated_config:
                updated_config['streaming'] = {}
            updated_config['streaming']['rtmp_server'] = rtmp_server
            
            # For backward compatibility also update old-style flat config
            updated_config['site_name'] = site_name
            updated_config['allow_registration'] = allow_registration
            updated_config['require_approval'] = require_approval
            updated_config['rtmp_server'] = rtmp_server
            updated_config['default_player'] = default_player
            
            # Save to file
            with open('config.yaml', 'w') as file:
                yaml.dump(updated_config, file)
            
            st.success("Settings saved successfully")
            st.info("For the admin dashboard URL change to take effect, you may need to restart the application.")
    
    # Media categories management
    st.subheader("Media Categories")
    
    if 'media_categories' in st.session_state:
        categories = st.session_state.media_categories
        
        # Display current categories
        st.write("Current Categories:")
        for i, category in enumerate(categories):
            col1, col2 = st.columns([3, 1])
            
            col1.write(category)
            
            # Don't allow deleting Uncategorized
            if category != "Uncategorized":
                if col2.button("Delete", key=f"delete_cat_{i}"):
                    from utils.media import delete_category
                    if delete_category(category):
                        st.success(f"Category '{category}' deleted")
                        st.rerun()
                    else:
                        st.error("Failed to delete category")
        
        # Add new category
        with st.form("add_category_form"):
            new_category = st.text_input("New Category Name")
            
            if st.form_submit_button("Add Category"):
                if not new_category:
                    st.error("Category name is required")
                else:
                    from utils.media import add_category
                    if add_category(new_category):
                        st.success(f"Category '{new_category}' added")
                        st.rerun()
                    else:
                        st.error("Failed to add category. Category may already exist.")

if __name__ == "__main__":
    main()
