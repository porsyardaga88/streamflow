import streamlit as st
from utils.auth import require_auth
from utils.media import (
    get_public_media, get_media_item, increment_view_count,
    add_comment, get_media_by_category, search_media, VIDEO, AUDIO, LIVE
)
from utils.stream import get_public_streams, get_stream_info
from utils.session import init_session_state

# Initialize session state variables
init_session_state()

# Set page configuration
st.set_page_config(
    page_title="Media Player - StreamFlow",
    page_icon="▶️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state for player
if 'current_media' not in st.session_state:
    st.session_state.current_media = None

def display_player(media_item):
    """Display the media player based on media type"""
    if not media_item:
        st.warning("No media selected. Choose a media item from the library.")
        return
    
    # Increment view count
    if 'last_viewed_media' not in st.session_state or st.session_state.last_viewed_media != media_item['id']:
        increment_view_count(media_item['id'])
        st.session_state.last_viewed_media = media_item['id']
    
    st.subheader(media_item['title'])
    
    # Get media source
    source = media_item.get('source', '')
    media_type = media_item.get('type', VIDEO)
    
    # Display appropriate player based on media type
    if media_type == LIVE:
        # For live streams, use the RTMP player
        st.write(f"Live Stream by: {media_item.get('owner', 'Unknown')}")
        
        # Display stream info
        stream_info = get_stream_info(source) if source else None
        if stream_info and stream_info.get('status') == 'active':
            st.success("Stream is active")
            
            # RTMP player using HTML iframe
            rtmp_url = f"rtmp://{stream_info.get('stream_key', '')}"
            player_html = f"""
            <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
                <iframe src="/player?stream={stream_info.get('stream_key', '')}" 
                        style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" 
                        frameborder="0" allowfullscreen>
                </iframe>
            </div>
            """
            st.components.v1.html(player_html, height=450)
        else:
            st.error("Stream is currently offline")
            
    elif media_type == VIDEO:
        # For video, use the video player component
        st.video(source)
        
    elif media_type == AUDIO:
        # For audio, use the audio player component
        st.audio(source)
    
    # Media details and metadata
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown(f"**Description:** {media_item.get('description', 'No description')}")
        st.markdown(f"**Category:** {media_item.get('category', 'Uncategorized')}")
        
        # Comments section
        st.subheader("Comments")
        
        # Add comment form
        if st.session_state.authenticated:
            comment_text = st.text_area("Add a comment", key=f"comment_{media_item['id']}")
            if st.button("Submit Comment"):
                if comment_text:
                    success, msg = add_comment(media_item['id'], comment_text)
                    if success:
                        st.success("Comment added successfully")
                        st.rerun()
                    else:
                        st.error(msg)
                else:
                    st.warning("Please enter a comment")
        else:
            st.info("Please log in to add comments")
        
        # Display comments
        comments = media_item.get('comments', [])
        if comments:
            for comment in comments:
                with st.container():
                    st.markdown(f"**{comment.get('user', 'Anonymous')}**")
                    st.markdown(comment.get('text', ''))
                    st.markdown(f"*{comment.get('timestamp', '')}*")
                    st.markdown("---")
        else:
            st.info("No comments yet.")
    
    with col2:
        st.markdown(f"**Views:** {media_item.get('views', 0)}")
        st.markdown(f"**Added by:** {media_item.get('owner', 'Unknown')}")
        st.markdown(f"**Date Added:** {media_item.get('created_at', 'Unknown')}")

def main():
    st.title("Media Player")
    
    # Sidebar for navigation and search
    with st.sidebar:
        # Search box
        search_query = st.text_input("Search Media", placeholder="Enter search terms...")
        
        # Category filter
        if 'media_categories' in st.session_state:
            selected_category = st.selectbox(
                "Filter by Category",
                ["All"] + st.session_state.media_categories
            )
        else:
            selected_category = "All"
        
        # Media type filter
        media_type_filter = st.selectbox(
            "Filter by Type",
            ["All", "Videos", "Audio", "Live Streams"]
        )
        
        # Apply filters
        if search_query:
            # If search query is provided, search media
            media_items = search_media(search_query)
        elif selected_category != "All":
            # If category is selected, filter by category
            media_items = get_media_by_category(selected_category)
        else:
            # Otherwise, get all public media
            media_items = get_public_media()
            
            # Get public streams and convert to media items
            public_streams = get_public_streams()
            for stream_id, stream_info in public_streams.items():
                if stream_info.get('status') == 'active':
                    # Convert active stream to media item
                    media_items.append({
                        'id': f"stream_{stream_id}",
                        'title': stream_info.get('title', 'Untitled Stream'),
                        'description': stream_info.get('description', 'No description'),
                        'type': LIVE,
                        'source': stream_id,
                        'owner': stream_info.get('owner', 'Unknown'),
                        'is_public': True,
                        'category': 'Live Streams',
                        'views': stream_info.get('viewers', 0),
                        'created_at': stream_info.get('created_at', '')
                    })
        
        # Apply media type filter
        if media_type_filter != "All":
            if media_type_filter == "Videos":
                media_items = [item for item in media_items if item.get('type') == VIDEO]
            elif media_type_filter == "Audio":
                media_items = [item for item in media_items if item.get('type') == AUDIO]
            elif media_type_filter == "Live Streams":
                media_items = [item for item in media_items if item.get('type') == LIVE]
        
        # Display filtered media items
        st.subheader("Available Media")
        
        if not media_items:
            st.info("No media items found.")
        else:
            # Create a list of media items
            for item in media_items:
                # Use expander for each item
                with st.expander(f"{item['title']} ({item.get('type', 'unknown').title()})"):
                    st.write(f"By: {item.get('owner', 'Unknown')}")
                    st.write(f"Category: {item.get('category', 'Uncategorized')}")
                    
                    # Play button
                    if st.button("Play", key=f"play_{item['id']}"):
                        st.session_state.current_media = item['id']
                        st.rerun()
    
    # Main content area - Player
    if st.session_state.current_media:
        # Get current media item
        current_id = st.session_state.current_media
        
        # Handle stream IDs
        if isinstance(current_id, str) and current_id.startswith('stream_'):
            stream_id = current_id.replace('stream_', '')
            stream_info = get_stream_info(stream_id)
            
            if stream_info:
                media_item = {
                    'id': current_id,
                    'title': stream_info.get('title', 'Untitled Stream'),
                    'description': stream_info.get('description', 'No description'),
                    'type': LIVE,
                    'source': stream_id,
                    'owner': stream_info.get('owner', 'Unknown'),
                    'is_public': True,
                    'category': 'Live Streams',
                    'views': stream_info.get('viewers', 0),
                    'created_at': stream_info.get('created_at', ''),
                    'comments': []
                }
                display_player(media_item)
            else:
                st.error("Stream not found or no longer available.")
                st.session_state.current_media = None
        else:
            # Regular media item
            media_item = get_media_item(current_id)
            
            if media_item:
                display_player(media_item)
            else:
                st.error("Media not found or no longer available.")
                st.session_state.current_media = None
    else:
        st.info("Select a media item from the sidebar to start playing.")
        
        # Featured section on main page when nothing is playing
        st.subheader("Featured Content")
        
        # Get featured media (newest or most viewed)
        featured_media = get_public_media()
        
        if featured_media:
            # Sort by views (most popular)
            featured_media = sorted(featured_media, key=lambda x: x.get('views', 0), reverse=True)[:4]
            
            # Display in a grid
            col1, col2 = st.columns(2)
            
            for i, item in enumerate(featured_media[:4]):
                with col1 if i % 2 == 0 else col2:
                    with st.container():
                        st.subheader(item['title'])
                        st.write(f"Category: {item.get('category', 'Uncategorized')}")
                        st.write(f"Views: {item.get('views', 0)}")
                        
                        if st.button("Play", key=f"featured_{item['id']}"):
                            st.session_state.current_media = item['id']
                            st.rerun()
                        
                        st.markdown("---")
        else:
            st.info("No featured content available.")

if __name__ == "__main__":
    main()
