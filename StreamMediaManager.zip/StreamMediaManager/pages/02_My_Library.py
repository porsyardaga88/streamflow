import streamlit as st
from utils.auth import require_auth
from utils.session import init_session_state

# Initialize session state variables
init_session_state()
from utils.media import (
    get_user_media, add_media, update_media, delete_media, 
    VIDEO, AUDIO, LIVE, is_valid_url, parse_duration, format_duration
)
from utils.stream import get_user_streams

# Set page configuration
st.set_page_config(
    page_title="My Library - StreamFlow",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Require authentication for this page
@require_auth
def main():
    st.title("My Media Library")
    
    # Add New Media section
    with st.expander("Add New Media", expanded=False):
        add_media_form()
    
    # Tabs for different media types
    tab1, tab2, tab3 = st.tabs(["Videos", "Audio", "Streams"])
    
    with tab1:
        display_user_videos()
    
    with tab2:
        display_user_audio()
    
    with tab3:
        display_user_streams()

def add_media_form():
    """Form for adding new media"""
    st.subheader("Add New Media")
    
    # Media details
    media_type = st.selectbox("Media Type", [VIDEO, AUDIO])
    title = st.text_input("Title")
    description = st.text_area("Description")
    source = st.text_input("Media URL")
    
    # Media category
    if 'media_categories' in st.session_state:
        category = st.selectbox("Category", st.session_state.media_categories)
    else:
        category = "Uncategorized"
    
    # Media visibility
    is_public = st.checkbox("Make Public", value=True)
    
    # Duration (optional)
    duration_str = st.text_input("Duration (HH:MM:SS)", placeholder="00:02:30")
    duration = parse_duration(duration_str) if duration_str else None
    
    # Submit button
    if st.button("Add Media"):
        if not title:
            st.error("Title is required")
        elif not source:
            st.error("Media URL is required")
        elif not is_valid_url(source):
            st.error("Please enter a valid URL")
        else:
            media_id, error = add_media(
                title=title,
                description=description,
                media_type=media_type,
                source=source,
                is_public=is_public,
                category=category,
                duration=duration
            )
            
            if media_id:
                st.success(f"Media added successfully!")
                st.rerun()
            else:
                st.error(f"Failed to add media: {error}")

def display_user_videos():
    """Display user's video media"""
    # Get user's video media
    user_videos = [item for item in get_user_media() if item.get('type') == VIDEO]
    
    if not user_videos:
        st.info("You don't have any videos in your library yet. Add some using the form above.")
    else:
        st.subheader(f"Your Videos ({len(user_videos)})")
        
        for video in user_videos:
            with st.container():
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.subheader(video['title'])
                    st.write(video.get('description', 'No description'))
                    st.write(f"Category: {video.get('category', 'Uncategorized')}")
                    
                with col2:
                    st.write(f"Duration: {format_duration(video.get('duration'))}")
                    st.write(f"Views: {video.get('views', 0)}")
                    st.write(f"Public: {'Yes' if video.get('is_public', False) else 'No'}")
                
                with col3:
                    # Action buttons
                    edit_key = f"edit_video_{video['id']}"
                    delete_key = f"delete_video_{video['id']}"
                    play_key = f"play_video_{video['id']}"
                    
                    if st.button("Edit", key=edit_key):
                        st.session_state.edit_media_id = video['id']
                        st.session_state.edit_media_tab = "video"
                        st.rerun()
                    
                    if st.button("Delete", key=delete_key):
                        if delete_media(video['id']):
                            st.success("Video deleted successfully")
                            st.rerun()
                        else:
                            st.error("Failed to delete video")
                    
                    if st.button("Play", key=play_key):
                        # Redirect to media player page with this video
                        st.session_state.current_media = video['id']
                        st.switch_page("pages/01_Media_Player.py")
                
                st.markdown("---")
        
        # Check if any video is being edited
        if hasattr(st.session_state, 'edit_media_id') and hasattr(st.session_state, 'edit_media_tab') and st.session_state.edit_media_tab == "video":
            edit_media_form(st.session_state.edit_media_id)

def display_user_audio():
    """Display user's audio media"""
    # Get user's audio media
    user_audio = [item for item in get_user_media() if item.get('type') == AUDIO]
    
    if not user_audio:
        st.info("You don't have any audio files in your library yet. Add some using the form above.")
    else:
        st.subheader(f"Your Audio Files ({len(user_audio)})")
        
        for audio in user_audio:
            with st.container():
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.subheader(audio['title'])
                    st.write(audio.get('description', 'No description'))
                    st.write(f"Category: {audio.get('category', 'Uncategorized')}")
                    
                with col2:
                    st.write(f"Duration: {format_duration(audio.get('duration'))}")
                    st.write(f"Views: {audio.get('views', 0)}")
                    st.write(f"Public: {'Yes' if audio.get('is_public', False) else 'No'}")
                
                with col3:
                    # Action buttons
                    edit_key = f"edit_audio_{audio['id']}"
                    delete_key = f"delete_audio_{audio['id']}"
                    play_key = f"play_audio_{audio['id']}"
                    
                    if st.button("Edit", key=edit_key):
                        st.session_state.edit_media_id = audio['id']
                        st.session_state.edit_media_tab = "audio"
                        st.rerun()
                    
                    if st.button("Delete", key=delete_key):
                        if delete_media(audio['id']):
                            st.success("Audio deleted successfully")
                            st.rerun()
                        else:
                            st.error("Failed to delete audio")
                    
                    if st.button("Play", key=play_key):
                        # Redirect to media player page with this audio
                        st.session_state.current_media = audio['id']
                        st.switch_page("pages/01_Media_Player.py")
                
                st.markdown("---")
        
        # Check if any audio is being edited
        if hasattr(st.session_state, 'edit_media_id') and hasattr(st.session_state, 'edit_media_tab') and st.session_state.edit_media_tab == "audio":
            edit_media_form(st.session_state.edit_media_id)

def display_user_streams():
    """Display user's streams"""
    # Get user's streams
    user_streams = get_user_streams()
    
    if not user_streams:
        st.info("You don't have any streams set up yet. Go to Stream Setup to create a stream.")
        if st.button("Go to Stream Setup"):
            st.switch_page("pages/03_Stream_Setup.py")
    else:
        st.subheader(f"Your Streams ({len(user_streams)})")
        
        for stream_id, stream_info in user_streams.items():
            with st.container():
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.subheader(stream_info.get('title', 'Untitled Stream'))
                    st.write(stream_info.get('description', 'No description'))
                    
                    # Display status badge
                    status = stream_info.get('status', 'idle')
                    if status == 'active':
                        st.success("Active")
                    elif status == 'error':
                        st.error("Error")
                    else:
                        st.info("Idle")
                    
                with col2:
                    st.write(f"Type: {stream_info.get('type', 'Unknown')}")
                    st.write(f"Viewers: {stream_info.get('viewers', 0)}")
                    st.write(f"Public: {'Yes' if stream_info.get('is_public', False) else 'No'}")
                
                with col3:
                    # Action buttons
                    setup_key = f"setup_stream_{stream_id}"
                    delete_key = f"delete_stream_{stream_id}"
                    
                    if st.button("Setup", key=setup_key):
                        # Redirect to stream setup page with this stream
                        st.session_state.current_stream_id = stream_id
                        st.switch_page("pages/03_Stream_Setup.py")
                    
                    # Delete button
                    if st.button("Delete", key=delete_key):
                        from utils.stream import delete_stream
                        if delete_stream(stream_id):
                            st.success("Stream deleted successfully")
                            st.rerun()
                        else:
                            st.error("Failed to delete stream")
                
                st.markdown("---")

def edit_media_form(media_id):
    """Form for editing media"""
    from utils.media import get_media_item
    
    media_item = get_media_item(media_id)
    if not media_item:
        st.error("Media not found")
        return
    
    st.subheader(f"Edit: {media_item['title']}")
    
    with st.form(key=f"edit_media_form_{media_id}"):
        # Media details
        title = st.text_input("Title", value=media_item.get('title', ''))
        description = st.text_area("Description", value=media_item.get('description', ''))
        source = st.text_input("Media URL", value=media_item.get('source', ''))
        
        # Media category
        if 'media_categories' in st.session_state:
            category = st.selectbox("Category", st.session_state.media_categories, 
                                   index=st.session_state.media_categories.index(media_item.get('category', 'Uncategorized'))
                                   if media_item.get('category', '') in st.session_state.media_categories else 0)
        else:
            category = "Uncategorized"
        
        # Media visibility
        is_public = st.checkbox("Make Public", value=media_item.get('is_public', True))
        
        # Duration (optional)
        duration = media_item.get('duration')
        duration_str = format_duration(duration).replace('Unknown', '') if duration else ''
        new_duration_str = st.text_input("Duration (HH:MM:SS)", value=duration_str, placeholder="00:02:30")
        new_duration = parse_duration(new_duration_str) if new_duration_str else duration
        
        # Submit button
        submit = st.form_submit_button("Save Changes")
        
        if submit:
            if not title:
                st.error("Title is required")
            elif not source:
                st.error("Media URL is required")
            elif not is_valid_url(source):
                st.error("Please enter a valid URL")
            else:
                # Update media
                updates = {
                    'title': title,
                    'description': description,
                    'source': source,
                    'is_public': is_public,
                    'category': category,
                    'duration': new_duration
                }
                
                if update_media(media_id, updates):
                    st.success("Media updated successfully")
                    # Clear edit state
                    del st.session_state.edit_media_id
                    del st.session_state.edit_media_tab
                    st.rerun()
                else:
                    st.error("Failed to update media")
    
    # Cancel button
    if st.button("Cancel Editing"):
        del st.session_state.edit_media_id
        del st.session_state.edit_media_tab
        st.rerun()

if __name__ == "__main__":
    main()
