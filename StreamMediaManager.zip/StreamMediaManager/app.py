import streamlit as st
import os
import yaml
from utils.auth import initialize_auth, login, register, logout, check_admin
from utils.install import check_dependencies
from utils.stream import get_stream_stats
from utils import hide_pages_from_sidebar

# Set page configuration
st.set_page_config(
    page_title="StreamFlow - Streaming Platform",
    page_icon="▶️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state using our helper
from utils.session import init_session_state
init_session_state()

# Load configuration
if os.path.exists('config.yaml'):
    with open('config.yaml', 'r') as file:
        config = yaml.safe_load(file)
else:
    config = {
        'site_name': 'StreamFlow',
        'allow_registration': True,
        'require_approval': False,
        'rtmp_server': 'rtmp://localhost/live',
        'default_player': 'vlc'
    }
    with open('config.yaml', 'w') as file:
        yaml.dump(config, file)

# Initialize auth system
initialize_auth()

# Hide the Admin Dashboard from sidebar for non-admin users
if not st.session_state.get('is_admin', False):
    hide_pages_from_sidebar(["04_Admin_Dashboard.py"])

# Main app
def main():
    # Sidebar navigation
    with st.sidebar:
        # Get site name from the config, handling both old and new config formats
        site_name = config.get('site_name', config.get('app', {}).get('name', 'StreamFlow'))
        st.title(site_name)
        
        if not st.session_state.authenticated:
            st.subheader("Login")
            login_tab, register_tab = st.tabs(["Login", "Register"])
            
            with login_tab:
                username = st.text_input("Username", key="login_username")
                password = st.text_input("Password", type="password", key="login_password")
                if st.button("Login"):
                    login_result = login(username, password)
                    if login_result:
                        st.success("Login successful!")
                        # Check if user is admin and redirect accordingly
                        if st.session_state.is_admin:
                            # Redirect admin to admin dashboard
                            admin_dashboard_path = config.get('auth', {}).get('admin_dashboard_path', "pages/04_Admin_Dashboard.py")
                            # Remove leading slashes and 'streamlit/' prefix for st.switch_page
                            if admin_dashboard_path.startswith('/'):
                                admin_dashboard_path = admin_dashboard_path[1:]
                            if admin_dashboard_path.startswith('streamlit/'):
                                admin_dashboard_path = admin_dashboard_path[10:]
                            st.switch_page(admin_dashboard_path)
                        else:
                            # Regular users stay on home page or go to Media Player
                            st.switch_page("pages/01_Media_Player.py")
                    else:
                        st.error("Invalid username or password")
            
            with register_tab:
                # Get registration setting from config, default to True if not found
                allow_registration = config.get('allow_registration', config.get('auth', {}).get('allow_registration', True))
                if allow_registration:
                    new_username = st.text_input("New Username", key="register_username")
                    new_password = st.text_input("New Password", type="password", key="register_password")
                    confirm_password = st.text_input("Confirm Password", type="password", key="confirm_password")
                    is_admin = st.checkbox("Register as Admin (requires approval)")
                    
                    if st.button("Register"):
                        if new_password != confirm_password:
                            st.error("Passwords do not match")
                        else:
                            register_result = register(new_username, new_password, is_admin)
                            if register_result:
                                st.success("Registration successful! You can now login.")
                            else:
                                st.error("Username already exists")
                else:
                    st.info("Registration is currently disabled by admin")
        else:
            st.success(f"Logged in as: {st.session_state.username}")
            
            # If user is admin, display admin status
            if st.session_state.is_admin:
                st.info("Admin Account")
                
                # Active stream stats for admins
                active_streams = get_stream_stats()
                if active_streams:
                    st.subheader("Active Streams")
                    for stream_id, stats in active_streams.items():
                        st.metric(f"Stream {stream_id}", f"{stats['viewers']} viewers")
            
            # Logout button
            if st.button("Logout"):
                logout()
                st.rerun()
    
    # Main content area
    if not st.session_state.authenticated:
        # Public home page for non-authenticated users
        st.title("Welcome to StreamFlow")
        st.subheader("Your all-in-one streaming platform")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            ### Features
            - Stream with VLC and RTMP protocols
            - Organize your media library
            - Easy integration with WordPress
            - Customizable stream settings
            """)
            
        with col2:
            st.markdown("""
            ### Getting Started
            1. Create an account
            2. Set up your streaming preferences
            3. Start streaming or browse available content
            """)
            
        # Dependency check for non-authenticated users
        st.subheader("System Check")
        if st.button("Check Dependencies"):
            dependency_status = check_dependencies()
            for dep, status in dependency_status.items():
                if status['installed']:
                    st.success(f"✅ {dep}: {status['version']}")
                else:
                    st.error(f"❌ {dep}: Not installed")
                    st.info(f"Install command: {status['install_cmd']}")
    else:
        # Authenticated user home page
        st.title(f"Welcome back, {st.session_state.username}!")
        
        # Recent activity and quick stats
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Media Items", len(st.session_state.media_library))
        
        with col2:
            # Count active streams for this user
            user_streams = sum(1 for stream in st.session_state.active_streams.values() 
                              if stream.get('owner') == st.session_state.username)
            st.metric("Active Streams", user_streams)
        
        with col3:
            # Display stream key for the user if exists
            if st.session_state.username in st.session_state.stream_keys:
                stream_key = st.session_state.stream_keys[st.session_state.username]
                st.text_input("Your Stream Key", value=stream_key, disabled=True)
            else:
                if st.button("Generate Stream Key"):
                    import uuid
                    st.session_state.stream_keys[st.session_state.username] = str(uuid.uuid4())
                    st.rerun()
        
        # Quick start section
        st.subheader("Quick Start Options")
        quick_start_cols = st.columns(3)
        
        with quick_start_cols[0]:
            st.markdown("#### Watch Streams")
            st.markdown("Browse available streams and media content")
            if st.button("Go to Media Player"):
                st.switch_page("pages/01_Media_Player.py")
        
        with quick_start_cols[1]:
            st.markdown("#### My Library")
            st.markdown("Manage your media files and streams")
            if st.button("Go to Library"):
                st.switch_page("pages/02_My_Library.py")
        
        with quick_start_cols[2]:
            st.markdown("#### Start Streaming")
            st.markdown("Configure and start your stream")
            if st.button("Stream Setup"):
                st.switch_page("pages/03_Stream_Setup.py")

if __name__ == "__main__":
    main()
