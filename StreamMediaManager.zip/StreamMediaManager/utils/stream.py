import os
import streamlit as st
import subprocess
import time
import uuid
import re
import yaml
from datetime import datetime

# Stream status constants
STREAM_IDLE = "idle"
STREAM_ACTIVE = "active"
STREAM_ERROR = "error"

def initialize_streaming():
    """Initialize streaming functionality"""
    if 'active_streams' not in st.session_state:
        st.session_state.active_streams = {}
    if 'stream_history' not in st.session_state:
        st.session_state.stream_history = []
    if 'stream_keys' not in st.session_state:
        st.session_state.stream_keys = {}

def generate_stream_key(username):
    """Generate a unique streaming key for a user"""
    if username not in st.session_state.stream_keys:
        stream_key = str(uuid.uuid4())
        st.session_state.stream_keys[username] = stream_key
        return stream_key
    return st.session_state.stream_keys[username]

def get_stream_key(username):
    """Get the stream key for a specific user"""
    return st.session_state.stream_keys.get(username, None)

def reset_stream_key(username):
    """Reset a user's stream key"""
    if username in st.session_state.stream_keys:
        st.session_state.stream_keys[username] = str(uuid.uuid4())
        return st.session_state.stream_keys[username]
    return None

def is_ffmpeg_installed():
    """Check if FFmpeg is installed"""
    try:
        result = subprocess.run(['ffmpeg', '-version'], 
                                capture_output=True, 
                                text=True, 
                                check=False)
        return result.returncode == 0
    except FileNotFoundError:
        return False

def is_vlc_installed():
    """Check if VLC is installed"""
    try:
        result = subprocess.run(['vlc', '--version'], 
                                capture_output=True, 
                                text=True, 
                                check=False)
        return result.returncode == 0
    except FileNotFoundError:
        return False

def get_rtmp_url(stream_key=None):
    """Get the RTMP URL for streaming"""
    # Load configuration
    if os.path.exists('config.yaml'):
        with open('config.yaml', 'r') as file:
            config = yaml.safe_load(file)
    else:
        config = {'rtmp_server': 'rtmp://localhost/live'}
    
    base_url = config.get('rtmp_server', 'rtmp://localhost/live')
    
    if stream_key:
        return f"{base_url}/{stream_key}"
    return base_url

def create_stream(title, description, stream_type, is_public=True):
    """Create a new stream"""
    if not st.session_state.authenticated:
        return None, "Authentication required"
    
    stream_id = str(uuid.uuid4())
    username = st.session_state.username
    
    # Generate stream key if user doesn't have one
    if username not in st.session_state.stream_keys:
        generate_stream_key(username)
    
    stream_key = st.session_state.stream_keys[username]
    
    # Create stream record
    st.session_state.active_streams[stream_id] = {
        "id": stream_id,
        "title": title,
        "description": description,
        "type": stream_type,  # "rtmp", "vlc", etc.
        "owner": username,
        "stream_key": stream_key,
        "created_at": datetime.now().isoformat(),
        "status": STREAM_IDLE,
        "is_public": is_public,
        "viewers": 0,
        "last_error": None
    }
    
    return stream_id, None

def get_stream_info(stream_id):
    """Get information about a specific stream"""
    return st.session_state.active_streams.get(stream_id, None)

def get_user_streams(username=None):
    """Get all streams for a specific user, or current user if username is None"""
    if username is None and st.session_state.authenticated:
        username = st.session_state.username
    
    if not username:
        return []
    
    return {
        stream_id: stream_info 
        for stream_id, stream_info in st.session_state.active_streams.items()
        if stream_info.get("owner") == username
    }

def get_public_streams():
    """Get all public streams"""
    return {
        stream_id: stream_info 
        for stream_id, stream_info in st.session_state.active_streams.items()
        if stream_info.get("is_public", False) and stream_info.get("status") == STREAM_ACTIVE
    }

def start_stream(stream_id):
    """Update stream status to active"""
    if stream_id in st.session_state.active_streams:
        st.session_state.active_streams[stream_id]["status"] = STREAM_ACTIVE
        st.session_state.active_streams[stream_id]["started_at"] = datetime.now().isoformat()
        return True
    return False

def stop_stream(stream_id):
    """Update stream status to idle"""
    if stream_id in st.session_state.active_streams:
        # Add to history
        stream_info = st.session_state.active_streams[stream_id].copy()
        stream_info["ended_at"] = datetime.now().isoformat()
        st.session_state.stream_history.append(stream_info)
        
        # Update stream status
        st.session_state.active_streams[stream_id]["status"] = STREAM_IDLE
        st.session_state.active_streams[stream_id]["viewers"] = 0
        return True
    return False

def delete_stream(stream_id):
    """Delete a stream"""
    if stream_id in st.session_state.active_streams:
        # Add to history before deleting
        stream_info = st.session_state.active_streams[stream_id].copy()
        stream_info["ended_at"] = datetime.now().isoformat()
        stream_info["deleted"] = True
        st.session_state.stream_history.append(stream_info)
        
        # Delete the stream
        del st.session_state.active_streams[stream_id]
        return True
    return False

def generate_rtmp_command(stream_id, input_source, video_bitrate="2500k", audio_bitrate="128k"):
    """Generate an FFmpeg command for RTMP streaming"""
    stream_info = get_stream_info(stream_id)
    if not stream_info:
        return None
    
    stream_key = stream_info["stream_key"]
    rtmp_url = get_rtmp_url(stream_key)
    
    # Basic command for streaming to RTMP server
    command = [
        "ffmpeg",
        "-i", input_source,
        "-c:v", "libx264",
        "-b:v", video_bitrate,
        "-c:a", "aac",
        "-b:a", audio_bitrate,
        "-f", "flv",
        rtmp_url
    ]
    
    return command

def generate_vlc_stream_command(input_source, stream_key, video_bitrate="2500k", audio_bitrate="128k"):
    """Generate a VLC command for streaming"""
    rtmp_url = get_rtmp_url(stream_key)
    
    # VLC command for streaming
    command = [
        "vlc",
        input_source,
        "--sout", f"#transcode{{vcodec=h264,vb={video_bitrate},acodec=mp4a,ab={audio_bitrate}}}:std{{access=rtmp,mux=flv,dst={rtmp_url}}}"
    ]
    
    return command

def get_stream_stats():
    """Get statistics about active streams"""
    active_count = sum(1 for stream in st.session_state.active_streams.values() 
                      if stream.get("status") == STREAM_ACTIVE)
    
    total_viewers = sum(stream.get("viewers", 0) for stream in st.session_state.active_streams.values())
    
    return {
        stream_id: {
            "title": stream.get("title", "Untitled"),
            "owner": stream.get("owner", "Unknown"),
            "viewers": stream.get("viewers", 0),
            "started_at": stream.get("started_at", None),
            "type": stream.get("type", "Unknown")
        }
        for stream_id, stream in st.session_state.active_streams.items()
        if stream.get("status") == STREAM_ACTIVE
    }

def get_streaming_instructions(stream_id):
    """Get instructions for streaming to this stream"""
    stream_info = get_stream_info(stream_id)
    if not stream_info:
        return None
    
    stream_key = stream_info["stream_key"]
    rtmp_url = get_rtmp_url(stream_key)
    
    instructions = {
        "rtmp": {
            "url": rtmp_url,
            "ffmpeg_cmd": f"ffmpeg -i [INPUT] -c:v libx264 -b:v 2500k -c:a aac -b:a 128k -f flv {rtmp_url}",
            "obs_settings": {
                "service": "Custom",
                "server": get_rtmp_url().rstrip("/live"),
                "stream_key": stream_key
            }
        },
        "vlc": {
            "cmd": f'vlc [INPUT] --sout "#transcode{{vcodec=h264,vb=2500k,acodec=mp4a,ab=128k}}:std{{access=rtmp,mux=flv,dst={rtmp_url}}}"'
        }
    }
    
    return instructions

def generate_embed_code(stream_id, width=640, height=360):
    """Generate embed code for a stream"""
    stream_info = get_stream_info(stream_id)
    if not stream_info:
        return None
    
    stream_key = stream_info["stream_key"]
    player_url = f"/player?stream={stream_key}"
    
    # iframe embed code
    iframe_code = f'<iframe src="{player_url}" width="{width}" height="{height}" frameborder="0" allowfullscreen></iframe>'
    
    # WordPress shortcode
    wp_shortcode = f'[streamflow stream="{stream_key}" width="{width}" height="{height}"]'
    
    return {
        "iframe": iframe_code,
        "shortcode": wp_shortcode
    }
