import streamlit as st
import yaml
import os
from datetime import datetime
import uuid

def initialize_wordpress():
    """Initialize WordPress integration settings"""
    if 'wordpress_settings' not in st.session_state:
        st.session_state.wordpress_settings = {
            'enabled': False,
            'site_url': '',
            'username': '',
            'application_password': '',
            'default_category': 'streaming',
            'auto_publish': False
        }
    
    if 'wordpress_templates' not in st.session_state:
        st.session_state.wordpress_templates = {
            'default': {
                'name': 'Default',
                'content': """
<!-- StreamFlow Player Embed -->
[streamflow_player stream="{stream_key}" width="640" height="360"]

<h2>{title}</h2>
<p>{description}</p>

<p>Stream started: {start_time}</p>
<p>Streamed by: {username}</p>
                """
            },
            'minimal': {
                'name': 'Minimal',
                'content': """
<!-- StreamFlow Player Embed -->
[streamflow_player stream="{stream_key}" width="100%" height="400"]
                """
            }
        }
    
    if 'wordpress_posts' not in st.session_state:
        st.session_state.wordpress_posts = []

def save_wordpress_settings(settings):
    """Save WordPress integration settings"""
    st.session_state.wordpress_settings.update(settings)
    return True

def get_wordpress_settings():
    """Get WordPress integration settings"""
    return st.session_state.wordpress_settings

def create_wordpress_template(name, content):
    """Create a new WordPress template"""
    template_id = str(uuid.uuid4())
    
    st.session_state.wordpress_templates[template_id] = {
        'name': name,
        'content': content
    }
    
    return template_id

def update_wordpress_template(template_id, name=None, content=None):
    """Update a WordPress template"""
    if template_id in st.session_state.wordpress_templates:
        if name:
            st.session_state.wordpress_templates[template_id]['name'] = name
        if content:
            st.session_state.wordpress_templates[template_id]['content'] = content
        return True
    return False

def delete_wordpress_template(template_id):
    """Delete a WordPress template"""
    if template_id in st.session_state.wordpress_templates and template_id not in ['default', 'minimal']:
        del st.session_state.wordpress_templates[template_id]
        return True
    return False

def get_wordpress_templates():
    """Get all WordPress templates"""
    return st.session_state.wordpress_templates

def get_wordpress_template(template_id):
    """Get a specific WordPress template"""
    return st.session_state.wordpress_templates.get(template_id, None)

def render_template(template_id, stream_info):
    """Render a WordPress template with stream information"""
    template = get_wordpress_template(template_id)
    if not template:
        return None
    
    content = template['content']
    
    # Replace placeholders with actual values
    replacements = {
        '{title}': stream_info.get('title', 'Untitled Stream'),
        '{description}': stream_info.get('description', ''),
        '{stream_key}': stream_info.get('stream_key', ''),
        '{username}': stream_info.get('owner', 'Anonymous'),
        '{start_time}': stream_info.get('started_at', datetime.now().isoformat()),
        '{stream_id}': stream_info.get('id', '')
    }
    
    for placeholder, value in replacements.items():
        content = content.replace(placeholder, str(value))
    
    return content

def create_wordpress_post(stream_id, template_id='default', title=None, category=None):
    """Create a WordPress post for a stream"""
    from utils.stream import get_stream_info
    
    stream_info = get_stream_info(stream_id)
    if not stream_info:
        return None, "Stream not found"
    
    settings = get_wordpress_settings()
    
    # Use provided title or stream title
    post_title = title or stream_info.get('title', 'Untitled Stream')
    
    # Use provided category or default
    post_category = category or settings.get('default_category', 'streaming')
    
    # Render the template
    post_content = render_template(template_id, stream_info)
    if not post_content:
        return None, "Template not found"
    
    # In a real implementation, we would use the WordPress REST API to create the post
    # For this MVP, we'll simulate post creation
    post_id = str(uuid.uuid4())
    
    post = {
        'id': post_id,
        'stream_id': stream_id,
        'title': post_title,
        'content': post_content,
        'category': post_category,
        'status': 'draft' if not settings.get('auto_publish', False) else 'published',
        'created_at': datetime.now().isoformat(),
        'wordpress_id': None  # This would be the actual WordPress post ID
    }
    
    st.session_state.wordpress_posts.append(post)
    
    return post_id, None

def publish_wordpress_post(post_id):
    """Publish a WordPress post"""
    for i, post in enumerate(st.session_state.wordpress_posts):
        if post.get('id') == post_id:
            st.session_state.wordpress_posts[i]['status'] = 'published'
            return True
    return False

def delete_wordpress_post(post_id):
    """Delete a WordPress post"""
    for i, post in enumerate(st.session_state.wordpress_posts):
        if post.get('id') == post_id:
            st.session_state.wordpress_posts.pop(i)
            return True
    return False

def get_wordpress_posts(stream_id=None):
    """Get WordPress posts, optionally filtered by stream_id"""
    if stream_id:
        return [post for post in st.session_state.wordpress_posts if post.get('stream_id') == stream_id]
    return st.session_state.wordpress_posts

def get_wordpress_post(post_id):
    """Get a specific WordPress post"""
    for post in st.session_state.wordpress_posts:
        if post.get('id') == post_id:
            return post
    return None

def generate_wordpress_plugin_code():
    """Generate code for a WordPress plugin that integrates with StreamFlow"""
    plugin_code = """<?php
/*
Plugin Name: StreamFlow Integration
Plugin URI: https://example.com/streamflow
Description: Integrates WordPress with StreamFlow streaming platform
Version: 1.0
Author: StreamFlow Team
Author URI: https://example.com
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main StreamFlow Plugin Class
 */
class StreamFlow_Plugin {
    /**
     * Constructor
     */
    public function __construct() {
        // Register shortcodes
        add_shortcode('streamflow_player', array($this, 'player_shortcode'));
        
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
    }
    
    /**
     * Player shortcode
     */
    public function player_shortcode($atts) {
        $atts = shortcode_atts(array(
            'stream' => '',
            'width' => '640',
            'height' => '360',
            'autoplay' => 'false',
        ), $atts, 'streamflow_player');
        
        if (empty($atts['stream'])) {
            return '<p>Error: Stream key is required.</p>';
        }
        
        $stream_key = esc_attr($atts['stream']);
        $width = esc_attr($atts['width']);
        $height = esc_attr($atts['height']);
        $autoplay = ($atts['autoplay'] === 'true') ? 'true' : 'false';
        
        // Get StreamFlow URL from settings
        $streamflow_url = get_option('streamflow_url', '');
        if (empty($streamflow_url)) {
            return '<p>Error: StreamFlow URL not configured in settings.</p>';
        }
        
        // Build the player URL
        $player_url = trailingslashit($streamflow_url) . 'player?stream=' . $stream_key;
        
        // Return the iframe
        return '<iframe src="' . esc_url($player_url) . '" width="' . $width . '" height="' . $height . '" frameborder="0" allowfullscreen></iframe>';
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'StreamFlow Settings',
            'StreamFlow',
            'manage_options',
            'streamflow-settings',
            array($this, 'settings_page'),
            'dashicons-video-alt3'
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('streamflow_settings', 'streamflow_url');
        register_setting('streamflow_settings', 'streamflow_api_key');
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>StreamFlow Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('streamflow_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">StreamFlow URL</th>
                        <td>
                            <input type="url" name="streamflow_url" value="<?php echo esc_attr(get_option('streamflow_url')); ?>" class="regular-text">
                            <p class="description">Enter the URL of your StreamFlow instance (e.g., https://example.com)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">API Key</th>
                        <td>
                            <input type="text" name="streamflow_api_key" value="<?php echo esc_attr(get_option('streamflow_api_key')); ?>" class="regular-text">
                            <p class="description">Enter your StreamFlow API key for advanced integration</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
            
            <h2>Shortcode Usage</h2>
            <p>Use the following shortcode to embed a StreamFlow player in your posts or pages:</p>
            <code>[streamflow_player stream="YOUR_STREAM_KEY" width="640" height="360" autoplay="false"]</code>
            
            <h3>Parameters:</h3>
            <ul>
                <li><strong>stream</strong> (required): Your StreamFlow stream key</li>
                <li><strong>width</strong> (optional): Player width in pixels or percentage (default: 640)</li>
                <li><strong>height</strong> (optional): Player height in pixels (default: 360)</li>
                <li><strong>autoplay</strong> (optional): Set to "true" to enable autoplay (default: false)</li>
            </ul>
        </div>
        <?php
    }
}

// Initialize the plugin
$streamflow_plugin = new StreamFlow_Plugin();
"""
    
    return plugin_code
