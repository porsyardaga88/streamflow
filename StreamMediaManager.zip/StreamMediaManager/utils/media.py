import os
import streamlit as st
import uuid
from datetime import datetime
import re

# Media type constants
VIDEO = "video"
AUDIO = "audio"
LIVE = "live"

def initialize_media():
    """Initialize the media library"""
    if 'media_library' not in st.session_state:
        st.session_state.media_library = []
        
    if 'media_categories' not in st.session_state:
        st.session_state.media_categories = ["Uncategorized", "Movies", "Music", "Live Streams", "Educational", "Sports"]

def add_media(title, description, media_type, source, owner=None, is_public=True, category="Uncategorized", thumbnail=None, duration=None):
    """Add a new media item to the library"""
    if not st.session_state.authenticated and owner is None:
        return None, "Authentication required"
    
    if owner is None:
        owner = st.session_state.username
    
    media_id = str(uuid.uuid4())
    
    # Create media record
    media_item = {
        "id": media_id,
        "title": title,
        "description": description,
        "type": media_type,  # VIDEO, AUDIO, LIVE
        "source": source,    # URL or stream key
        "owner": owner,
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "is_public": is_public,
        "category": category,
        "thumbnail": thumbnail,
        "views": 0,
        "likes": 0,
        "duration": duration,
        "comments": []
    }
    
    st.session_state.media_library.append(media_item)
    
    return media_id, None

def get_media_item(media_id):
    """Get a specific media item by ID"""
    for item in st.session_state.media_library:
        if item.get("id") == media_id:
            return item
    return None

def update_media(media_id, updates):
    """Update a media item"""
    for i, item in enumerate(st.session_state.media_library):
        if item.get("id") == media_id:
            # Check permission
            if st.session_state.authenticated and (item.get("owner") == st.session_state.username or st.session_state.is_admin):
                updates["updated_at"] = datetime.now().isoformat()
                st.session_state.media_library[i].update(updates)
                return True
            return False
    return False

def delete_media(media_id):
    """Delete a media item"""
    for i, item in enumerate(st.session_state.media_library):
        if item.get("id") == media_id:
            # Check permission
            if st.session_state.authenticated and (item.get("owner") == st.session_state.username or st.session_state.is_admin):
                st.session_state.media_library.pop(i)
                return True
            return False
    return False

def get_user_media(username=None):
    """Get all media items for a specific user, or current user if username is None"""
    if username is None and st.session_state.authenticated:
        username = st.session_state.username
    
    if not username:
        return []
    
    return [
        item for item in st.session_state.media_library
        if item.get("owner") == username
    ]

def get_public_media():
    """Get all public media items"""
    return [
        item for item in st.session_state.media_library
        if item.get("is_public", False)
    ]

def get_media_by_category(category):
    """Get media items by category"""
    return [
        item for item in st.session_state.media_library
        if item.get("category") == category and item.get("is_public", False)
    ]

def search_media(query):
    """Search media items by query string"""
    if not query:
        return []
    
    query = query.lower()
    
    results = []
    for item in st.session_state.media_library:
        if (query in item.get("title", "").lower() or
            query in item.get("description", "").lower() or
            query in item.get("category", "").lower()):
            
            # Include if public or owned by current user
            if (item.get("is_public", False) or 
                (st.session_state.authenticated and item.get("owner") == st.session_state.username)):
                results.append(item)
    
    return results

def increment_view_count(media_id):
    """Increment the view count for a media item"""
    for i, item in enumerate(st.session_state.media_library):
        if item.get("id") == media_id:
            st.session_state.media_library[i]["views"] = item.get("views", 0) + 1
            return True
    return False

def add_comment(media_id, comment_text):
    """Add a comment to a media item"""
    if not st.session_state.authenticated:
        return False, "Authentication required"
    
    for i, item in enumerate(st.session_state.media_library):
        if item.get("id") == media_id:
            comment = {
                "id": str(uuid.uuid4()),
                "user": st.session_state.username,
                "text": comment_text,
                "timestamp": datetime.now().isoformat()
            }
            
            if "comments" not in st.session_state.media_library[i]:
                st.session_state.media_library[i]["comments"] = []
                
            st.session_state.media_library[i]["comments"].append(comment)
            return True, None
    
    return False, "Media item not found"

def add_category(category_name):
    """Add a new category"""
    if category_name and category_name not in st.session_state.media_categories:
        st.session_state.media_categories.append(category_name)
        return True
    return False

def delete_category(category_name):
    """Delete a category and move items to Uncategorized"""
    if category_name in st.session_state.media_categories and category_name != "Uncategorized":
        # Move all items in this category to Uncategorized
        for i, item in enumerate(st.session_state.media_library):
            if item.get("category") == category_name:
                st.session_state.media_library[i]["category"] = "Uncategorized"
        
        # Remove the category
        st.session_state.media_categories.remove(category_name)
        return True
    return False

def is_valid_url(url):
    """Check if a string is a valid URL"""
    regex = re.compile(
        r'^(?:http|ftp)s?://'  # http:// or https:// or ftp:// or ftps://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain
        r'localhost|'  # localhost
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # or IP
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    return re.match(regex, url) is not None

def is_stream_url(url):
    """Check if a URL is likely a stream URL"""
    stream_protocols = ['rtmp://', 'rtsp://', 'http://live.', 'https://live.', 'hls://', 'srt://']
    return any(url.startswith(protocol) for protocol in stream_protocols)

def parse_duration(duration_str):
    """Parse duration string (HH:MM:SS) to seconds"""
    if not duration_str:
        return None
    
    try:
        parts = duration_str.split(':')
        if len(parts) == 3:
            hours, minutes, seconds = parts
            return int(hours) * 3600 + int(minutes) * 60 + int(seconds)
        elif len(parts) == 2:
            minutes, seconds = parts
            return int(minutes) * 60 + int(seconds)
        else:
            return int(parts[0])
    except:
        return None

def format_duration(seconds):
    """Format seconds into HH:MM:SS"""
    if seconds is None:
        return "Unknown"
    
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    else:
        return f"{minutes:02d}:{seconds:02d}"
