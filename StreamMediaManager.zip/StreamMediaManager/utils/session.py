import streamlit as st
import os
import yaml

def init_session_state():
    """Initialize all session state variables needed for the application"""
    print("Initializing session state...")
    
    # Initialize authentication variables
    if 'authenticated' not in st.session_state:
        print("Setting authenticated = False")
        st.session_state.authenticated = False
    if 'username' not in st.session_state:
        print("Setting username = None")
        st.session_state.username = None
    if 'is_admin' not in st.session_state:
        print("Setting is_admin = False")
        st.session_state.is_admin = False
    
    # Initialize user management
    if 'users' not in st.session_state:
        print("Initializing users dictionary")
        st.session_state.users = {}
        
        # Create default admin for initial setup in session.py
        from utils.auth import hash_password, ADMIN_ROLE
        from datetime import datetime
        
        admin_username = "admin"
        admin_password = "admin"
        hashed_password = hash_password(admin_password)
        
        print(f"Creating default admin user in session.py: {admin_username}")
        
        st.session_state.users[admin_username] = {
            "password": hashed_password,
            "role": ADMIN_ROLE,
            "approved": True,
            "created_at": datetime.now().isoformat(),
            "last_login": None
        }
    
    # Debug info for user accounts
    print(f"Users in session: {list(st.session_state.users.keys())}")
    
    # Initialize media library
    if 'media_library' not in st.session_state:
        print("Initializing media_library")
        st.session_state.media_library = []
    if 'media_categories' not in st.session_state:
        print("Initializing media_categories")
        st.session_state.media_categories = ["Uncategorized"]
        
    # Initialize streaming
    if 'active_streams' not in st.session_state:
        print("Initializing active_streams")
        st.session_state.active_streams = {}
    if 'stream_keys' not in st.session_state:
        print("Initializing stream_keys")
        st.session_state.stream_keys = {}
    
    # Initialize WordPress integration variables
    if 'wordpress_settings' not in st.session_state:
        print("Initializing wordpress_settings")
        st.session_state.wordpress_settings = {
            'enabled': False,
            'api_url': None,
            'api_username': None,
            'api_password': None
        }
    if 'wordpress_templates' not in st.session_state:
        print("Initializing wordpress_templates")
        st.session_state.wordpress_templates = {
            'default': {
                'name': 'Default Template',
                'content': 'Default content template'
            }
        }
    if 'wordpress_posts' not in st.session_state:
        print("Initializing wordpress_posts")
        st.session_state.wordpress_posts = {}