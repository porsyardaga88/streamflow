import streamlit as st
import hashlib
import yaml
import os
from datetime import datetime

# User roles
USER_ROLE = "user"
ADMIN_ROLE = "admin"

def initialize_auth():
    """Initialize the authentication system"""
    if 'users' not in st.session_state:
        st.session_state.users = {}
    
    # Create default admin user if no users exist
    if not st.session_state.users or "admin" not in st.session_state.users:
        # Default admin account
        admin_username = "admin"
        admin_password = "admin"  # In production, use a secure password
        hashed_password = hashlib.sha256(admin_password.encode()).hexdigest()
        
        st.session_state.users[admin_username] = {
            "password": hashed_password,
            "role": ADMIN_ROLE,
            "approved": True,
            "created_at": datetime.now().isoformat(),
            "last_login": None
        }
        
        # Debug info
        print("Created default admin user:", admin_username, "password:", admin_password)

def hash_password(password):
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def login(username, password):
    """Authenticate user and set session state"""
    if not username or not password:
        print("Login failed: Empty username or password")
        return False
    
    print("Login attempt for user:", username)
    print("Current users in session:", list(st.session_state.users.keys()))
        
    if username in st.session_state.users:
        stored_password = st.session_state.users[username]["password"]
        hashed_input = hash_password(password)
        
        print("Password check for:", username)
        print("Stored hash:", stored_password)
        print("Input hash:", hashed_input)
        print("Password match:", stored_password == hashed_input)
        
        if stored_password == hashed_input:
            # Check if user is approved
            is_approved = st.session_state.users[username].get("approved", False)
            print("User approved status:", is_approved)
            
            if not is_approved:
                st.warning("Your account is pending approval by an administrator.")
                return False
                
            # Set session state
            st.session_state.authenticated = True
            st.session_state.username = username
            st.session_state.is_admin = st.session_state.users[username]["role"] == ADMIN_ROLE
            
            print("User authenticated successfully")
            print("Is admin:", st.session_state.is_admin)
            
            # Update last login
            st.session_state.users[username]["last_login"] = datetime.now().isoformat()
            return True
    else:
        print("User not found:", username)
    
    return False

def register(username, password, is_admin=False):
    """Register a new user"""
    if not username or not password:
        return False
        
    # Check if username already exists
    if username in st.session_state.users:
        return False
        
    # Load config to check if approval is required
    if os.path.exists('config.yaml'):
        with open('config.yaml', 'r') as file:
            config = yaml.safe_load(file)
    else:
        config = {'require_approval': False}
    
    # Create new user
    hashed_password = hash_password(password)
    
    # Determine if user needs approval
    needs_approval = config.get('require_approval', False)
    is_approved = not needs_approval and not is_admin  # Admin accounts always need approval
    
    st.session_state.users[username] = {
        "password": hashed_password,
        "role": ADMIN_ROLE if is_admin else USER_ROLE,
        "approved": is_approved,
        "created_at": datetime.now().isoformat(),
        "last_login": None
    }
    
    return True

def logout():
    """Log out the current user"""
    st.session_state.authenticated = False
    st.session_state.username = None
    st.session_state.is_admin = False

def check_admin():
    """Check if current user is an admin"""
    return st.session_state.authenticated and st.session_state.is_admin

def get_all_users():
    """Get all users (admin only)"""
    return st.session_state.users

def approve_user(username):
    """Approve a pending user (admin only)"""
    if username in st.session_state.users:
        st.session_state.users[username]["approved"] = True
        return True
    return False

def change_user_role(username, new_role):
    """Change a user's role (admin only)"""
    if username in st.session_state.users and new_role in [USER_ROLE, ADMIN_ROLE]:
        st.session_state.users[username]["role"] = new_role
        return True
    return False

def delete_user(username):
    """Delete a user (admin only)"""
    if username in st.session_state.users:
        del st.session_state.users[username]
        return True
    return False

def require_auth(func):
    """Decorator to require authentication"""
    def wrapper(*args, **kwargs):
        if not st.session_state.authenticated:
            st.error("You must be logged in to access this page")
            st.stop()
        return func(*args, **kwargs)
    return wrapper

def require_admin(func):
    """Decorator to require admin privileges"""
    def wrapper(*args, **kwargs):
        if not check_admin():
            st.error("You must be an admin to access this page")
            st.stop()
        return func(*args, **kwargs)
    return wrapper
