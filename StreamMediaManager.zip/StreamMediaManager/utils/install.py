import platform
import subprocess
import sys
import os
import streamlit as st

def check_dependencies():
    """Check if necessary dependencies are installed"""
    dependencies = {
        "ffmpeg": {
            "installed": False,
            "version": None,
            "install_cmd": get_ffmpeg_install_cmd()
        },
        "vlc": {
            "installed": False,
            "version": None,
            "install_cmd": get_vlc_install_cmd()
        },
        "python-vlc": {
            "installed": False,
            "version": None,
            "install_cmd": "pip install python-vlc"
        },
        "ffmpeg-python": {
            "installed": False,
            "version": None,
            "install_cmd": "pip install ffmpeg-python"
        }
    }
    
    # Check FFmpeg
    try:
        result = subprocess.run(['ffmpeg', '-version'], 
                                capture_output=True, 
                                text=True, 
                                check=False)
        if result.returncode == 0:
            dependencies["ffmpeg"]["installed"] = True
            # Extract version from first line
            version_line = result.stdout.split('\n')[0]
            if 'version' in version_line:
                dependencies["ffmpeg"]["version"] = version_line.split('version')[1].strip().split(' ')[0]
    except FileNotFoundError:
        pass
    
    # Check VLC
    try:
        result = subprocess.run(['vlc', '--version'], 
                                capture_output=True, 
                                text=True, 
                                check=False)
        if result.returncode == 0:
            dependencies["vlc"]["installed"] = True
            # Extract version from output
            version_line = result.stdout.split('\n')[0]
            dependencies["vlc"]["version"] = version_line.strip()
    except FileNotFoundError:
        pass
    
    # Check Python packages
    try:
        # Check python-vlc
        import vlc
        dependencies["python-vlc"]["installed"] = True
        dependencies["python-vlc"]["version"] = vlc.__version__ if hasattr(vlc, "__version__") else "Unknown"
    except ImportError:
        pass
    
    try:
        # Check ffmpeg-python
        import ffmpeg
        dependencies["ffmpeg-python"]["installed"] = True
        dependencies["ffmpeg-python"]["version"] = ffmpeg.__version__ if hasattr(ffmpeg, "__version__") else "Unknown"
    except ImportError:
        pass
    
    return dependencies

def get_ffmpeg_install_cmd():
    """Get the FFmpeg installation command for the current platform"""
    system = platform.system().lower()
    
    if system == 'linux':
        return "sudo apt update && sudo apt install -y ffmpeg"
    elif system == 'darwin':  # macOS
        return "brew install ffmpeg"
    elif system == 'windows':
        return "Download from https://ffmpeg.org/download.html or use: choco install ffmpeg"
    else:
        return "Visit https://ffmpeg.org/download.html"

def get_vlc_install_cmd():
    """Get the VLC installation command for the current platform"""
    system = platform.system().lower()
    
    if system == 'linux':
        return "sudo apt update && sudo apt install -y vlc"
    elif system == 'darwin':  # macOS
        return "brew install vlc"
    elif system == 'windows':
        return "Download from https://www.videolan.org/vlc/ or use: choco install vlc"
    else:
        return "Visit https://www.videolan.org/vlc/"

def install_python_package(package_name):
    """Install a Python package using pip"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        return True, f"Successfully installed {package_name}"
    except subprocess.CalledProcessError as e:
        return False, f"Failed to install {package_name}: {str(e)}"

def install_ffmpeg():
    """Attempt to install FFmpeg"""
    system = platform.system().lower()
    
    try:
        if system == 'linux':
            subprocess.check_call(["sudo", "apt", "update"])
            subprocess.check_call(["sudo", "apt", "install", "-y", "ffmpeg"])
            return True, "Successfully installed FFmpeg"
        elif system == 'darwin':  # macOS
            subprocess.check_call(["brew", "install", "ffmpeg"])
            return True, "Successfully installed FFmpeg"
        else:
            return False, "Automatic installation not supported on this platform. Please install manually."
    except subprocess.CalledProcessError as e:
        return False, f"Failed to install FFmpeg: {str(e)}"
    except FileNotFoundError:
        return False, "Package manager not found. Please install FFmpeg manually."

def install_vlc():
    """Attempt to install VLC"""
    system = platform.system().lower()
    
    try:
        if system == 'linux':
            subprocess.check_call(["sudo", "apt", "update"])
            subprocess.check_call(["sudo", "apt", "install", "-y", "vlc"])
            return True, "Successfully installed VLC"
        elif system == 'darwin':  # macOS
            subprocess.check_call(["brew", "install", "vlc"])
            return True, "Successfully installed VLC"
        else:
            return False, "Automatic installation not supported on this platform. Please install manually."
    except subprocess.CalledProcessError as e:
        return False, f"Failed to install VLC: {str(e)}"
    except FileNotFoundError:
        return False, "Package manager not found. Please install VLC manually."

def ensure_directories():
    """Ensure necessary directories exist"""
    # For an actual application, we might create directories for storing config files,
    # user data, media files, etc. For Streamlit, we'll use session state instead.
    pass

def generate_install_script():
    """Generate an installation script for dependencies"""
    system = platform.system().lower()
    
    if system == 'linux':
        script = """#!/bin/bash
echo "Installing StreamFlow dependencies..."

# Update package lists
sudo apt update

# Install FFmpeg
echo "Installing FFmpeg..."
sudo apt install -y ffmpeg

# Install VLC
echo "Installing VLC..."
sudo apt install -y vlc

# Install Python packages
echo "Installing Python packages..."
pip install python-vlc ffmpeg-python

echo "Installation complete!"
"""
    elif system == 'darwin':  # macOS
        script = """#!/bin/bash
echo "Installing StreamFlow dependencies..."

# Check if Homebrew is installed
if ! command -v brew &> /dev/null; then
    echo "Homebrew not found. Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Install FFmpeg
echo "Installing FFmpeg..."
brew install ffmpeg

# Install VLC
echo "Installing VLC..."
brew install vlc

# Install Python packages
echo "Installing Python packages..."
pip install python-vlc ffmpeg-python

echo "Installation complete!"
"""
    elif system == 'windows':
        script = """@echo off
echo Installing StreamFlow dependencies...

:: Check if Chocolatey is installed
where choco >nul 2>&1
if %errorlevel% neq 0 (
    echo Chocolatey not found. Please install manually:
    echo https://chocolatey.org/install
    pause
    exit /b
)

:: Install FFmpeg
echo Installing FFmpeg...
choco install ffmpeg -y

:: Install VLC
echo Installing VLC...
choco install vlc -y

:: Install Python packages
echo Installing Python packages...
pip install python-vlc ffmpeg-python

echo Installation complete!
pause
"""
    else:
        script = """# StreamFlow Installation
# Please install the following dependencies manually:
#
# 1. FFmpeg - https://ffmpeg.org/download.html
# 2. VLC - https://www.videolan.org/vlc/
# 3. Python packages:
#    pip install python-vlc ffmpeg-python
"""
    
    return script

def save_install_script():
    """Save the installation script to a file"""
    script = generate_install_script()
    system = platform.system().lower()
    
    if system == 'windows':
        filename = "install_dependencies.bat"
    else:
        filename = "install_dependencies.sh"
    
    with open(filename, 'w') as f:
        f.write(script)
    
    # Make the script executable on Unix-like systems
    if system != 'windows':
        os.chmod(filename, 0o755)
    
    return filename
