# Import common functions
from .auth import (
    initialize_auth, login, register, logout, 
    check_admin, get_all_users, approve_user,
    change_user_role, delete_user, require_auth,
    require_admin
)

from .stream import (
    initialize_streaming, generate_stream_key, get_stream_key,
    reset_stream_key, create_stream, get_stream_info,
    get_user_streams, get_public_streams, start_stream,
    stop_stream, delete_stream, get_stream_stats,
    get_streaming_instructions, generate_embed_code
)

from .media import (
    initialize_media, add_media, get_media_item,
    update_media, delete_media, get_user_media,
    get_public_media, get_media_by_category, search_media,
    increment_view_count, add_comment
)

from .install import (
    check_dependencies, get_ffmpeg_install_cmd,
    get_vlc_install_cmd, install_python_package,
    install_ffmpeg, install_vlc, generate_install_script,
    save_install_script
)

from .wordpress import (
    initialize_wordpress, save_wordpress_settings,
    get_wordpress_settings, create_wordpress_template,
    update_wordpress_template, delete_wordpress_template,
    get_wordpress_templates, get_wordpress_template,
    render_template, create_wordpress_post,
    publish_wordpress_post, delete_wordpress_post,
    get_wordpress_posts, get_wordpress_post,
    generate_wordpress_plugin_code
)

# Custom functions for UI management
def hide_pages_from_sidebar(pages_to_hide):
    """
    Hide specific pages from the Streamlit sidebar.
    
    Args:
        pages_to_hide (list): List of page names to hide from the sidebar.
        
    Example:
        hide_pages_from_sidebar(["04_Admin_Dashboard.py"])
    """
    import streamlit as st
    import os
    import base64
    
    # Add custom CSS to hide specific pages
    hide_pages_css = """
    <style>
    """
    
    for page in pages_to_hide:
        # Create a unique selector for each page to hide
        page_name = os.path.basename(page)
        hide_pages_css += f"""
        [data-testid="stSidebar"] [aria-expanded="true"] ul li:has(a[href*="{page_name}"]) {{
            display: none !important;
        }}
        """
    
    hide_pages_css += """
    </style>
    """
    
    # Inject CSS to hide pages
    st.markdown(hide_pages_css, unsafe_allow_html=True)
